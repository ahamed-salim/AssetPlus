import { 
  Asset, 
  WarrantyRecord, 
  RepairRecord, 
  Employee, 
  Department 
} from '../types';

export interface StructuredData {
  type: 'assets' | 'warranties' | 'repairs' | 'employee' | 'summary';
  title?: string;
  assets?: Asset[];
  warranties?: WarrantyRecord[];
  repairs?: RepairRecord[];
  employee?: Employee;
  stats?: { label: string; value: string | number; color?: string }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  structuredData?: StructuredData;
  suggestedFollowUps?: string[];
}

export interface AIContext {
  assets: Asset[];
  warranties: WarrantyRecord[];
  repairs: RepairRecord[];
  employees: Employee[];
  departments: Department[];
}

/**
 * API-Ready AI Service Layer for AssetPulse
 * Can be swapped with live Gemini API endpoint or server-side /api/ai route.
 */
export async function queryAssetPulseAI(
  userQuery: string,
  context: AIContext
): Promise<ChatMessage> {
  // Simulate network API latency
  await new Promise((resolve) => setTimeout(resolve, 750));

  const q = userQuery.toLowerCase().trim();
  const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const messageId = `msg_${Date.now()}`;

  // 1. "Where is AST-2026-001?" or Specific Asset Tag Search
  const tagMatch = userQuery.match(/AST-[A-Za-z0-9-]+/i) || q.match(/tag\s+([a-z0-9-]+)/i);
  if (tagMatch || q.includes('where is')) {
    const targetTag = tagMatch ? tagMatch[0].toUpperCase() : 'AST-2026-001';
    const foundAsset = context.assets.find(
      (a) => a.tag.toUpperCase() === targetTag || a.tag.toUpperCase().includes(targetTag)
    ) || context.assets[0];

    if (foundAsset) {
      return {
        id: messageId,
        sender: 'assistant',
        timestamp,
        text: `Asset **${foundAsset.tag}** (**${foundAsset.name}**) is currently registered at **${foundAsset.location}**. \n\n**Status:** ${foundAsset.status}\n**Assigned To:** ${foundAsset.assignedEmployeeName || 'Unassigned (In Storage)'}\n**Department:** ${foundAsset.departmentName}`,
        structuredData: {
          type: 'assets',
          title: `Asset Location & Ownership: ${foundAsset.tag}`,
          assets: [foundAsset]
        },
        suggestedFollowUps: [
          `Who is using ${foundAsset.tag}?`,
          `Show warranty details for ${foundAsset.tag}`,
          `Check transfer history for ${foundAsset.tag}`
        ]
      };
    }
  }

  // 2. "Who is using this laptop?" / Custody & Employee Assignments
  if (q.includes('who is using') || q.includes('who has') || q.includes('laptop') || q.includes('assigned to')) {
    const laptops = context.assets.filter(
      (a) => a.category.toLowerCase().includes('laptop') || a.name.toLowerCase().includes('macbook') || a.name.toLowerCase().includes('thinkpad') || a.name.toLowerCase().includes('dell')
    );

    return {
      id: messageId,
      sender: 'assistant',
      timestamp,
      text: `I analyzed the repository for laptop custody. Here are the active laptop assignments across departments. Currently, **${laptops.filter(l => l.assignedEmployeeName).length} of ${laptops.length} laptops** are checked out to personnel.`,
      structuredData: {
        type: 'assets',
        title: 'Laptops & Mobile Compute Assignments',
        assets: laptops.slice(0, 4)
      },
      suggestedFollowUps: [
        'Show all unassigned laptops in storage',
        'Which department has the most laptops?',
        'Show assets under repair'
      ]
    };
  }

  // 3. "Which warranties expire this month?" / Warranty Tracking
  if (q.includes('warrant') || q.includes('expire') || q.includes('coverage')) {
    const expiringWarranties = context.warranties.filter(
      (w) => w.status === 'Expiring Soon' || w.status === 'Expired' || w.status === 'Active'
    );

    return {
      id: messageId,
      sender: 'assistant',
      timestamp,
      text: `I found **${context.warranties.length} warranty policies** logged in the system. Here are the policies that require attention or renewal within 30-60 days to prevent uncovered hardware risk.`,
      structuredData: {
        type: 'warranties',
        title: 'Warranty Expiration & Claims Alert',
        warranties: expiringWarranties.slice(0, 4)
      },
      suggestedFollowUps: [
        'How do I file a warranty claim?',
        'Show vendor details for Dell',
        'Show assets under repair'
      ]
    };
  }

  // 4. "Show assets under repair." / Repairs & Downtime
  if (q.includes('repair') || q.includes('maintenance') || q.includes('downtime') || q.includes('ticket')) {
    const activeRepairs = context.repairs.filter((r) => r.status !== 'Completed');
    const underRepairAssets = context.assets.filter(
      (a) => a.status === 'Under Repair' || a.status === 'Maintenance'
    );

    return {
      id: messageId,
      sender: 'assistant',
      timestamp,
      text: `There are currently **${underRepairAssets.length} assets under repair** with active work orders. Total accumulated repair expenditure across current tickets is **$${context.repairs.reduce((sum, r) => sum + (r.repairCost || 0), 0).toLocaleString()}**.`,
      structuredData: {
        type: 'repairs',
        title: 'Active Hardware Repair Tickets',
        repairs: context.repairs.slice(0, 4)
      },
      suggestedFollowUps: [
        'Which vendor has the longest repair turnaround?',
        'Which warranties expire this month?',
        'Where is AST-2026-001?'
      ]
    };
  }

  // 5. "Department / Financials / Stats" Queries
  if (q.includes('value') || q.includes('cost') || q.includes('department') || q.includes('summary')) {
    const totalVal = context.assets.reduce((sum, a) => sum + (a.purchaseCost || 0), 0);

    return {
      id: messageId,
      sender: 'assistant',
      timestamp,
      text: `Here is the high-level financial summary of your asset inventory:\n\n- **Total Portfolio Value:** $${totalVal.toLocaleString()}\n- **Total Managed Items:** ${context.assets.length}\n- **Active Employees:** ${context.employees.length}\n- **Departments Served:** ${context.departments.length}`,
      structuredData: {
        type: 'summary',
        title: 'Enterprise Portfolio High-Level Snapshot',
        stats: [
          { label: 'Total Value', value: `$${totalVal.toLocaleString()}`, color: 'emerald' },
          { label: 'Total Assets', value: context.assets.length, color: 'blue' },
          { label: 'Active Repairs', value: context.repairs.filter(r => r.status !== 'Completed').length, color: 'amber' },
          { label: 'Expiring Warranties', value: context.warranties.filter(w => w.status === 'Expiring Soon').length, color: 'rose' }
        ]
      },
      suggestedFollowUps: [
        'Show assets under repair',
        'Which warranties expire this month?',
        'Who is using this laptop?'
      ]
    };
  }

  // Generic Fallback with Keyword Search in Dataset
  const searchResults = context.assets.filter(a => 
    a.name.toLowerCase().includes(q) || 
    a.tag.toLowerCase().includes(q) || 
    a.category.toLowerCase().includes(q) ||
    a.departmentName.toLowerCase().includes(q)
  );

  if (searchResults.length > 0) {
    return {
      id: messageId,
      sender: 'assistant',
      timestamp,
      text: `I searched the asset repository for **"${userQuery}"** and found **${searchResults.length} matching item(s)**:`,
      structuredData: {
        type: 'assets',
        title: `Search Results for "${userQuery}"`,
        assets: searchResults.slice(0, 4)
      },
      suggestedFollowUps: [
        'Where is AST-2026-001?',
        'Who is using this laptop?',
        'Which warranties expire this month?'
      ]
    };
  }

  return {
    id: messageId,
    sender: 'assistant',
    timestamp,
    text: `I examined the system database for **"${userQuery}"**. I can query live assets by tag, employee custody, warranty expiration status, repair work tickets, and department allocations. \n\nTry one of the suggested quick questions below to inspect live records.`,
    suggestedFollowUps: [
      'Where is AST-2026-001?',
      'Who is using this laptop?',
      'Which warranties expire this month?',
      'Show assets under repair.'
    ]
  };
}
