import {
  User,
  Asset,
  Department,
  Employee,
  Vendor,
  AssignmentTransfer,
  LifecycleEvent,
  ComplaintTicket,
  RepairRecord,
  PreventiveMaintenance,
  WarrantyRecord,
  AssetAudit,
  AuditItem,
  DisposalRecord,
  ActivityLog,
  SystemStats
} from '../types';

import { calculateWarrantyStatus } from '../utils/warranty';

import {
  mockUsers,
  mockDepartments,
  mockEmployees,
  mockVendors,
  mockAssets,
  mockTransfers,
  mockComplaints,
  mockRepairs,
  mockPMs,
  mockWarranties,
  mockAudits,
  mockDisposals,
  mockActivityLogs,
  mockSystemStats
} from '../data/mockData';

// Storage keys
const STORAGE_KEYS = {
  TOKEN: 'assetpulse_auth_token',
  USER: 'assetpulse_current_user',
  USERS: 'assetpulse_users',
  ASSETS: 'assetpulse_assets',
  TRANSFERS: 'assetpulse_transfers',
  COMPLAINTS: 'assetpulse_complaints',
  REPAIRS: 'assetpulse_repairs',
  PMS: 'assetpulse_pms',
  AUDITS: 'assetpulse_audits',
  DISPOSALS: 'assetpulse_disposals',
  WARRANTIES: 'assetpulse_warranties',
  EMPLOYEES: 'assetpulse_employees',
  DEPARTMENTS: 'assetpulse_departments',
};

export function getAuthToken(): string | null {
  return localStorage.getItem(STORAGE_KEYS.TOKEN);
}

export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem(STORAGE_KEYS.TOKEN, token);
  } else {
    localStorage.removeItem(STORAGE_KEYS.TOKEN);
  }
}

export function getAuthHeaders(): Record<string, string> {
  const token = getAuthToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

// Helper for local storage read with fallback
function getStored<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    return fallback;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('LocalStorage failed:', e);
  }
}

// Users Directory API
export function getUsers(): User[] {
  return getStored<User[]>(STORAGE_KEYS.USERS, mockUsers);
}

export function saveUsers(users: User[]): void {
  setStored(STORAGE_KEYS.USERS, users);
}

// Current Active User
export function getCurrentUser(): User {
  return getStored<User>(STORAGE_KEYS.USER, mockUsers[0]);
}

export function setCurrentUser(user: User): void {
  setStored(STORAGE_KEYS.USER, user);
}

export function updateUserRecord(id: string, updates: Partial<User>): User | undefined {
  const users = getUsers();
  const idx = users.findIndex(u => u.id === id);
  if (idx === -1) return undefined;

  const updated: User = { ...users[idx], ...updates };
  users[idx] = updated;
  saveUsers(users);

  // If updating current user, sync currentUser in storage as well
  const current = getCurrentUser();
  if (current && current.id === id) {
    setCurrentUser(updated);
  }

  // Also sync backend
  fetch(`/api/users/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify(updates)
  }).catch(err => console.warn('Backend user update error:', err));

  return updated;
}

export function createUserRecord(data: Omit<User, 'id'>): User {
  const users = getUsers();
  const id = `USR-${String(users.length + 1).padStart(3, '0')}`;
  const newUser: User = {
    ...data,
    id,
    status: data.status || 'Active',
    avatar: data.avatar || `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`
  };

  const updated = [...users, newUser];
  saveUsers(updated);

  fetch('/api/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(newUser)
  }).catch(err => console.warn('Backend user creation error:', err));

  return newUser;
}

export function deleteUserRecord(id: string): boolean {
  const users = getUsers();
  const filtered = users.filter(u => u.id !== id);
  if (filtered.length < users.length) {
    saveUsers(filtered);
    fetch(`/api/users/${id}`, { method: 'DELETE' }).catch(err => console.warn('Backend user delete error:', err));
    return true;
  }
  return false;
}

// Assets API
export function getAssets(): Asset[] {
  const assets = getStored<Asset[]>(STORAGE_KEYS.ASSETS, mockAssets);
  return assets.map((a) => ({
    ...a,
    warrantyStatus: calculateWarrantyStatus(a.warrantyExpiry)
  }));
}

export function saveAssets(assets: Asset[]): void {
  setStored(STORAGE_KEYS.ASSETS, assets);
}

export function getAssetById(id: string): Asset | undefined {
  const assets = getAssets();
  return assets.find((a) => a.id === id || a.tag === id);
}

export function addAsset(newAsset: Omit<Asset, 'id' | 'qrCode' | 'timeline'>): Asset {
  const assets = getAssets();
  const id = `AST-2026-${String(assets.length + 1).padStart(3, '0')}`;
  const qrCode = `AP-${newAsset.tag}-${id}`;
  
  const created: Asset = {
    ...newAsset,
    id,
    qrCode,
    timeline: [
      {
        id: `TL-${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        title: 'Asset Registered',
        type: 'Purchase',
        description: `Created asset ${newAsset.name} in category ${newAsset.category}`,
        actor: getCurrentUser().name
      }
    ]
  };

  const updated = [created, ...assets];
  saveAssets(updated);
  return created;
}

export function updateAsset(id: string, updates: Partial<Asset>): Asset | undefined {
  const assets = getAssets();
  const idx = assets.findIndex((a) => a.id === id);
  if (idx === -1) return undefined;

  const current = assets[idx];
  const updatedAsset: Asset = {
    ...current,
    ...updates,
  };

  assets[idx] = updatedAsset;
  saveAssets(assets);
  return updatedAsset;
}

export function deleteAsset(id: string): boolean {
  const assets = getAssets();
  const filtered = assets.filter((a) => a.id !== id && a.tag !== id);
  if (filtered.length < assets.length) {
    saveAssets(filtered);
    return true;
  }
  return false;
}

// Transfers API
export function getTransfers(): AssignmentTransfer[] {
  return getStored<AssignmentTransfer[]>(STORAGE_KEYS.TRANSFERS, mockTransfers);
}

export function createTransfer(
  transfer: Omit<AssignmentTransfer, 'id' | 'requestedDate' | 'status'> & {
    requestedDate?: string;
    autoApprove?: boolean;
    status?: AssignmentTransfer['status'];
  }
): AssignmentTransfer {
  const transfers = getTransfers();
  const id = `TRF-${1000 + transfers.length + 1}`;
  const reqDate = transfer.requestedDate || new Date().toISOString().split('T')[0];
  const isAutoApproved = transfer.autoApprove === true || transfer.status === 'Approved' || transfer.status === 'Completed';
  const finalStatus: AssignmentTransfer['status'] = isAutoApproved ? 'Completed' : 'Pending Approval';

  const newRecord: AssignmentTransfer = {
    ...transfer,
    id,
    requestedDate: reqDate,
    status: finalStatus,
  };

  const updated = [newRecord, ...transfers];
  setStored(STORAGE_KEYS.TRANSFERS, updated);

  // Update asset assignment & lifecycle history
  const asset = getAssetById(transfer.assetId);
  if (asset) {
    if (isAutoApproved) {
      const isCheckin = transfer.type === 'Checkin';
      const newEmployee = isCheckin ? undefined : (transfer.toEmployee && transfer.toEmployee !== 'IT Pool' ? transfer.toEmployee : undefined);
      const newDept = transfer.toDept || asset.departmentName;
      const newLoc = transfer.toLocation || asset.location;
      const newStatus = isCheckin ? 'Available' : 'In Use';

      const timelineEvent = {
        id: `TL-${Date.now()}`,
        date: reqDate,
        title: transfer.type === 'Checkout' ? 'Equipment Checked Out' : transfer.type === 'Checkin' ? 'Equipment Checked In' : 'Equipment Transferred',
        type: (transfer.type === 'Checkin' ? 'Assignment' : 'Transfer') as LifecycleEvent['type'],
        description: `Action: ${transfer.type} | Previous: [Cust: ${transfer.fromEmployee || 'IT Pool'}, Dept: ${transfer.fromDept || 'N/A'}, Loc: ${transfer.fromLocation || asset.location}] → New: [Cust: ${transfer.toEmployee || 'IT Pool'}, Dept: ${transfer.toDept || 'N/A'}, Loc: ${newLoc}]. Justification: ${transfer.reason}`,
        actor: transfer.requestedBy || getCurrentUser().name
      };

      updateAsset(asset.id, {
        assignedEmployeeName: newEmployee,
        departmentName: newDept,
        location: newLoc,
        status: newStatus,
        timeline: [timelineEvent, ...(asset.timeline || [])]
      });
    } else {
      const timelineEvent = {
        id: `TL-${Date.now()}`,
        date: reqDate,
        title: 'Transfer Request Created',
        type: 'Transfer' as const,
        description: `Transfer #${id} Pending Approval: Request to move from ${transfer.fromEmployee || 'IT Pool'} (${transfer.fromDept || 'N/A'}) to ${transfer.toEmployee || 'IT Pool'} (${transfer.toDept || 'N/A'}, Loc: ${transfer.toLocation || 'N/A'}). Reason: ${transfer.reason}`,
        actor: transfer.requestedBy || getCurrentUser().name
      };

      updateAsset(asset.id, {
        status: 'Pending Transfer',
        timeline: [timelineEvent, ...(asset.timeline || [])]
      });
    }
  }

  return newRecord;
}

export function updateTransferStatus(id: string, status: AssignmentTransfer['status']): void {
  const transfers = getTransfers();
  const idx = transfers.findIndex(t => t.id === id);
  if (idx !== -1) {
    transfers[idx].status = status;
    setStored(STORAGE_KEYS.TRANSFERS, transfers);

    const trf = transfers[idx];
    const asset = getAssetById(trf.assetId);

    if (asset) {
      if (status === 'Approved' || status === 'Completed') {
        const isCheckin = trf.type === 'Checkin';
        const newEmployee = isCheckin ? undefined : (trf.toEmployee && trf.toEmployee !== 'IT Pool' ? trf.toEmployee : undefined);
        const newDept = trf.toDept || asset.departmentName;
        const newLoc = trf.toLocation || asset.location;
        const newStatus = isCheckin ? 'Available' : 'In Use';

        const timelineEvent = {
          id: `TL-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          title: `Transfer Approved (${trf.type})`,
          type: (trf.type === 'Checkin' ? 'Assignment' : 'Transfer') as LifecycleEvent['type'],
          description: `Approved Transfer #${trf.id}: Assigned to ${trf.toEmployee || 'IT Pool'} (${trf.toDept || 'N/A'}, Loc: ${newLoc}). Previous: ${trf.fromEmployee || 'IT Pool'} (${trf.fromDept || 'N/A'}). Reason: ${trf.reason}`,
          actor: getCurrentUser().name
        };

        updateAsset(asset.id, {
          assignedEmployeeName: newEmployee,
          departmentName: newDept,
          location: newLoc,
          status: newStatus,
          timeline: [timelineEvent, ...(asset.timeline || [])]
        });
      } else if (status === 'Rejected') {
        const timelineEvent = {
          id: `TL-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          title: 'Transfer Request Rejected',
          type: 'Transfer' as const,
          description: `Transfer #${trf.id} rejected by ${getCurrentUser().name}. Asset retained current assignment.`,
          actor: getCurrentUser().name
        };

        const currentStatus = asset.assignedEmployeeName ? 'In Use' : 'Available';
        updateAsset(asset.id, {
          status: currentStatus,
          timeline: [timelineEvent, ...(asset.timeline || [])]
        });
      }
    }
  }
}

// Complaints API
export function getComplaints(): ComplaintTicket[] {
  return getStored<ComplaintTicket[]>(STORAGE_KEYS.COMPLAINTS, mockComplaints);
}

export function createComplaint(complaint: Omit<ComplaintTicket, 'id' | 'createdAt' | 'status'>): ComplaintTicket {
  const list = getComplaints();
  const id = `TKT-${800 + list.length + 1}`;
  const created: ComplaintTicket = {
    ...complaint,
    id,
    createdAt: new Date().toISOString(),
    status: 'Open'
  };
  setStored(STORAGE_KEYS.COMPLAINTS, [created, ...list]);

  // Log lifecycle event on asset
  const asset = getAssetById(complaint.assetId);
  if (asset) {
    const timelineEvent: LifecycleEvent = {
      id: `TL-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      title: 'Support Ticket Filed',
      type: 'Repair',
      description: `Complaint #${id} (${complaint.priority} Priority): ${complaint.title}`,
      actor: complaint.raisedBy
    };
    updateAsset(asset.id, {
      timeline: [timelineEvent, ...(asset.timeline || [])]
    });
  }

  return created;
}

export function updateComplaint(id: string, updates: Partial<ComplaintTicket>): ComplaintTicket | undefined {
  const list = getComplaints();
  const idx = list.findIndex(c => c.id === id);
  if (idx !== -1) {
    const updated = { ...list[idx], ...updates };
    if (updates.status === 'Resolved' || updates.status === 'Closed') {
      updated.resolvedAt = new Date().toISOString();
    }
    list[idx] = updated;
    setStored(STORAGE_KEYS.COMPLAINTS, list);

    // Sync asset timeline if resolved
    if (updates.status === 'Resolved' || updates.status === 'Closed') {
      const asset = getAssetById(updated.assetId);
      if (asset) {
        const timelineEvent: LifecycleEvent = {
          id: `TL-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          title: 'Support Ticket Resolved',
          type: 'Repair',
          description: `Ticket #${id} resolved by ${updated.assignedTech || 'Technician'}. Notes: ${updated.resolutionNotes || updated.repairAction || 'Issue resolved.'}`,
          actor: updated.assignedTech || 'Technician'
        };
        updateAsset(asset.id, {
          timeline: [timelineEvent, ...(asset.timeline || [])]
        });
      }
    }

    return updated;
  }
  return undefined;
}

export function updateComplaintStatus(id: string, status: ComplaintTicket['status'], tech?: string, notes?: string, diagnosis?: string, repairAction?: string, cost?: number): void {
  updateComplaint(id, {
    status,
    ...(tech ? { assignedTech: tech } : {}),
    ...(notes ? { resolutionNotes: notes } : {}),
    ...(diagnosis ? { diagnosis } : {}),
    ...(repairAction ? { repairAction } : {}),
    ...(cost !== undefined ? { cost } : {})
  });
}

// Repairs API
export function getRepairs(): RepairRecord[] {
  return getStored<RepairRecord[]>(STORAGE_KEYS.REPAIRS, mockRepairs);
}

export function createRepair(repair: Omit<RepairRecord, 'id' | 'status'>): RepairRecord {
  const list = getRepairs();
  const id = `RPR-${500 + list.length + 1}`;
  const created: RepairRecord = {
    ...repair,
    id,
    status: 'In Repair'
  };
  setStored(STORAGE_KEYS.REPAIRS, [created, ...list]);

  // Update asset status to 'Under Repair' and add lifecycle event
  const asset = getAssetById(repair.assetId);
  if (asset) {
    const timelineEvent: LifecycleEvent = {
      id: `TL-${Date.now()}`,
      date: repair.startDate || new Date().toISOString().split('T')[0],
      title: 'Work Order / Repair Initiated',
      type: 'Repair',
      description: `Repair #${id}: ${repair.issueDescription}. Technician: ${repair.technicianName} (${repair.vendorName})`,
      actor: repair.technicianName || getCurrentUser().name
    };

    updateAsset(asset.id, {
      status: 'Under Repair',
      condition: 'Needs Repair',
      timeline: [timelineEvent, ...(asset.timeline || [])]
    });
  }

  return created;
}

export function updateRepair(id: string, updates: Partial<RepairRecord>): RepairRecord | undefined {
  const list = getRepairs();
  const idx = list.findIndex(r => r.id === id);
  if (idx !== -1) {
    const updated = { ...list[idx], ...updates };
    list[idx] = updated;
    setStored(STORAGE_KEYS.REPAIRS, list);

    // If repair is completed, restore asset status to In Use / Available
    if (updates.status === 'Completed') {
      const asset = getAssetById(updated.assetId);
      if (asset) {
        const newStatus = asset.assignedEmployeeName ? 'In Use' : 'Available';
        const timelineEvent: LifecycleEvent = {
          id: `TL-${Date.now()}`,
          date: updated.endDate || new Date().toISOString().split('T')[0],
          title: 'Hardware Repair Completed',
          type: 'Repair',
          description: `Work order #${id} completed. Action: ${updated.repairAction || 'Serviced'}. Total Cost: $${updated.repairCost}`,
          actor: updated.technicianName || 'Technician'
        };

        updateAsset(asset.id, {
          status: newStatus,
          condition: 'Good',
          timeline: [timelineEvent, ...(asset.timeline || [])]
        });
      }
    }

    return updated;
  }
  return undefined;
}

// Warranties API
export function getWarranties(): WarrantyRecord[] {
  const warranties = getStored<WarrantyRecord[]>(STORAGE_KEYS.WARRANTIES, mockWarranties);
  return warranties.map(w => ({
    ...w,
    status: calculateWarrantyStatus(w.expiryDate)
  }));
}

export function saveWarranties(warranties: WarrantyRecord[]): void {
  setStored(STORAGE_KEYS.WARRANTIES, warranties);
}

export function createWarranty(data: Omit<WarrantyRecord, 'id' | 'status'>): WarrantyRecord {
  const list = getWarranties();
  const id = `WRN-${300 + list.length + 1}`;
  const status = calculateWarrantyStatus(data.expiryDate);
  const created: WarrantyRecord = {
    ...data,
    id,
    status
  };

  const updatedList = [created, ...list];
  saveWarranties(updatedList);

  // Sync with Asset
  const asset = getAssetById(data.assetId);
  if (asset) {
    updateAsset(asset.id, {
      warrantyExpiry: data.expiryDate,
      warrantyVendor: data.vendorName,
      warrantyStatus: status,
      timeline: [
        {
          id: `TL-${Date.now()}`,
          date: new Date().toISOString().split('T')[0],
          title: 'Warranty Policy Registered',
          type: 'Purchase',
          description: `Registered policy ${data.policyNumber} with vendor ${data.vendorName}. Expiry: ${data.expiryDate}`,
          actor: getCurrentUser().name
        },
        ...(asset.timeline || [])
      ]
    });
  }

  return created;
}

export function updateWarrantyRecord(id: string, updates: Partial<WarrantyRecord>): WarrantyRecord | undefined {
  const list = getWarranties();
  const idx = list.findIndex(w => w.id === id);
  if (idx !== -1) {
    const updated: WarrantyRecord = {
      ...list[idx],
      ...updates,
      status: updates.expiryDate ? calculateWarrantyStatus(updates.expiryDate) : list[idx].status
    };
    list[idx] = updated;
    saveWarranties(list);

    if (updated.assetId) {
      const asset = getAssetById(updated.assetId);
      if (asset) {
        updateAsset(asset.id, {
          warrantyExpiry: updated.expiryDate,
          warrantyVendor: updated.vendorName,
          warrantyStatus: updated.status
        });
      }
    }

    return updated;
  }
  return undefined;
}

export function renewWarrantyPolicy(
  id: string,
  newExpiryDate: string,
  newVendorName?: string,
  newPolicyNumber?: string,
  coverageDetails?: string
): WarrantyRecord | undefined {
  const list = getWarranties();
  const idx = list.findIndex(w => w.id === id);
  if (idx !== -1) {
    const current = list[idx];
    const newStatus = calculateWarrantyStatus(newExpiryDate);
    const updated: WarrantyRecord = {
      ...current,
      expiryDate: newExpiryDate,
      vendorName: newVendorName || current.vendorName,
      policyNumber: newPolicyNumber || current.policyNumber,
      coverageDetails: coverageDetails || current.coverageDetails,
      status: newStatus
    };
    list[idx] = updated;
    saveWarranties(list);

    const asset = getAssetById(current.assetId);
    if (asset) {
      updateAsset(asset.id, {
        warrantyExpiry: newExpiryDate,
        warrantyVendor: updated.vendorName,
        warrantyStatus: newStatus,
        timeline: [
          {
            id: `TL-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            title: 'Warranty Policy Renewed',
            type: 'Purchase',
            description: `Extended warranty coverage through ${newExpiryDate} under policy ${updated.policyNumber}`,
            actor: getCurrentUser().name
          },
          ...(asset.timeline || [])
        ]
      });
    }

    return updated;
  }
  return undefined;
}

export function claimWarrantyPolicy(
  id: string,
  description: string,
  actorName?: string
): WarrantyRecord | undefined {
  const list = getWarranties();
  const idx = list.findIndex(w => w.id === id);
  if (idx !== -1) {
    const current = list[idx];
    const updated: WarrantyRecord = {
      ...current,
      claimCount: (current.claimCount || 0) + 1
    };
    list[idx] = updated;
    saveWarranties(list);

    const asset = getAssetById(current.assetId);
    if (asset) {
      updateAsset(asset.id, {
        timeline: [
          {
            id: `TL-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            title: 'Warranty Service Claim Filed',
            type: 'Repair',
            description: `Filed warranty claim #${updated.claimCount} with ${current.vendorName} (Ref: ${current.policyNumber}). Issue: ${description}`,
            actor: actorName || getCurrentUser().name
          },
          ...(asset.timeline || [])
        ]
      });
    }

    return updated;
  }
  return undefined;
}

export function getPMs(): PreventiveMaintenance[] {
  return getStored<PreventiveMaintenance[]>(STORAGE_KEYS.PMS, mockPMs);
}

export function createPM(pm: Omit<PreventiveMaintenance, 'id'>): PreventiveMaintenance {
  const list = getPMs();
  const id = `PM-${200 + list.length + 1}`;
  const created: PreventiveMaintenance = {
    ...pm,
    id
  };
  setStored(STORAGE_KEYS.PMS, [created, ...list]);
  return created;
}

export function updatePM(id: string, updates: Partial<PreventiveMaintenance>): PreventiveMaintenance | undefined {
  const list = getPMs();
  const idx = list.findIndex(p => p.id === id);
  if (idx !== -1) {
    const updated = { ...list[idx], ...updates };
    list[idx] = updated;
    setStored(STORAGE_KEYS.PMS, list);
    return updated;
  }
  return undefined;
}

export function togglePMTask(pmId: string, taskId: string): void {
  const list = getPMs();
  const pm = list.find(p => p.id === pmId);
  if (pm) {
    const task = pm.checklist.find(t => t.id === taskId);
    if (task) {
      task.completed = !task.completed;
      setStored(STORAGE_KEYS.PMS, list);
    }
  }
}

export function executePM(pmId: string, techName: string, notes?: string, actualCost?: number, targetAssetId?: string): void {
  const list = getPMs();
  const pm = list.find(p => p.id === pmId);
  if (pm) {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    // Compute next due date based on frequency
    const nextDate = new Date(today);
    if (pm.frequency === 'Monthly') nextDate.setMonth(nextDate.getMonth() + 1);
    else if (pm.frequency === 'Quarterly') nextDate.setMonth(nextDate.getMonth() + 3);
    else if (pm.frequency === 'Bi-Annually') nextDate.setMonth(nextDate.getMonth() + 6);
    else if (pm.frequency === 'Annual') nextDate.setFullYear(nextDate.getFullYear() + 1);

    pm.lastPerformedDate = todayStr;
    pm.nextDueDate = nextDate.toISOString().split('T')[0];
    if (actualCost !== undefined) pm.actualCost = actualCost;
    if (notes) pm.notes = notes;
    pm.status = 'Completed';

    // Reset checklist items to uncompleted for next cycle
    pm.checklist.forEach(c => (c.completed = false));

    setStored(STORAGE_KEYS.PMS, list);

    // If target asset is specified or linked
    const assetId = targetAssetId || pm.assetId;
    if (assetId) {
      const asset = getAssetById(assetId);
      if (asset) {
        const timelineEvent: LifecycleEvent = {
          id: `TL-${Date.now()}`,
          date: todayStr,
          title: 'Preventive Maintenance Executed',
          type: 'Maintenance',
          description: `PM Routine "${pm.title}" executed. Tech: ${techName}. ${notes ? 'Notes: ' + notes : ''}`,
          actor: techName
        };
        updateAsset(asset.id, {
          timeline: [timelineEvent, ...(asset.timeline || [])]
        });
      }
    }
  }
}

// Audits API
export function getAudits(): AssetAudit[] {
  return getStored<AssetAudit[]>(STORAGE_KEYS.AUDITS, mockAudits);
}

export function saveAudits(audits: AssetAudit[]): void {
  setStored(STORAGE_KEYS.AUDITS, audits);
}

export function createAudit(
  campaignName: string,
  targetDepartment: string,
  targetLocation: string,
  auditorName: string,
  startDate: string,
  endDate: string,
  notes?: string
): AssetAudit {
  const list = getAudits();
  const allAssets = getAssets();

  // Filter target assets matching department and location (exclude already disposed)
  const matchingAssets = allAssets.filter(a => {
    if (a.status === 'Disposed') return false;
    if (targetDepartment !== 'All' && targetDepartment !== 'All Departments' && a.departmentName !== targetDepartment) {
      return false;
    }
    if (targetLocation !== 'All' && targetLocation !== 'All Locations' && !a.location.toLowerCase().includes(targetLocation.toLowerCase())) {
      return false;
    }
    return true;
  });

  const items: AuditItem[] = matchingAssets.map(a => ({
    assetId: a.id,
    assetName: a.name,
    assetTag: a.tag,
    category: a.category,
    expectedLocation: a.location,
    assignedEmployeeName: a.assignedEmployeeName || 'Unassigned',
    status: 'Pending',
    notes: ''
  }));

  const id = `AUD-2026-${String(list.length + 1).padStart(2, '0')}`;
  const created: AssetAudit = {
    id,
    campaignName,
    targetDepartment,
    targetLocation,
    auditorName,
    startDate,
    endDate,
    status: 'In Progress',
    totalExpected: items.length,
    totalScanned: 0,
    items,
    notes: notes || ''
  };

  const updatedList = [created, ...list];
  saveAudits(updatedList);
  return created;
}

export function verifyAuditItem(
  auditId: string,
  assetId: string,
  status: 'Found' | 'Missing' | 'Damaged',
  notes?: string,
  verifiedBy?: string
): AssetAudit | undefined {
  const list = getAudits();
  const audit = list.find(a => a.id === auditId);
  if (!audit) return undefined;

  const item = audit.items.find(i => i.assetId === assetId);
  if (item) {
    const todayNow = new Date().toISOString().replace('T', ' ').slice(0, 16);
    item.status = status;
    item.notes = notes !== undefined ? notes : item.notes;
    item.verifiedAt = todayNow;
    item.verifiedBy = verifiedBy || getCurrentUser().name;

    audit.totalScanned = audit.items.filter(i => i.status !== 'Pending').length;
    saveAudits(list);

    // Sync timeline & condition with Asset
    const asset = getAssetById(assetId);
    if (asset) {
      const updates: Partial<Asset> = {
        timeline: [
          {
            id: `TL-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            title: `Audit Verification: ${status}`,
            type: 'Audit',
            description: `Verified in campaign "${audit.campaignName}". Status: ${status}. Notes: ${notes || 'N/A'}`,
            actor: verifiedBy || getCurrentUser().name
          },
          ...(asset.timeline || [])
        ]
      };

      if (status === 'Damaged') {
        updates.condition = 'Needs Repair';
      }

      updateAsset(asset.id, updates);
    }

    return audit;
  }
  return undefined;
}

export function completeAuditCampaign(auditId: string, notes?: string): AssetAudit | undefined {
  const list = getAudits();
  const audit = list.find(a => a.id === auditId);
  if (audit) {
    audit.status = 'Completed';
    audit.completedAt = new Date().toISOString().split('T')[0];
    if (notes) audit.notes = notes;
    saveAudits(list);
    return audit;
  }
  return undefined;
}

export function scanAssetInAudit(auditId: string, assetTagOrId: string): { success: boolean; message: string; asset?: Asset; audit?: AssetAudit } {
  const list = getAudits();
  const audit = list.find(a => a.id === auditId);
  const asset = getAssetById(assetTagOrId);

  if (!audit) return { success: false, message: 'Audit campaign not found.' };
  if (!asset) return { success: false, message: `Asset tag '${assetTagOrId}' not found in system repository.` };

  const item = audit.items.find(i => i.assetId === asset.id || i.assetTag === asset.tag);
  if (item) {
    verifyAuditItem(audit.id, item.assetId, 'Found', 'Verified via QR/Barcode Scan', getCurrentUser().name);
    const updatedAudit = getAudits().find(a => a.id === auditId);
    return { success: true, message: `Scanned & verified ${asset.name} (${asset.tag}) as Found!`, asset, audit: updatedAudit };
  } else {
    return { success: false, message: `Asset ${asset.name} (${asset.tag}) is not part of this campaign target scope.` };
  }
}

// Disposals API
export function getDisposals(): DisposalRecord[] {
  return getStored<DisposalRecord[]>(STORAGE_KEYS.DISPOSALS, mockDisposals);
}

export function saveDisposals(disposals: DisposalRecord[]): void {
  setStored(STORAGE_KEYS.DISPOSALS, disposals);
}

export function createDisposal(data: Omit<DisposalRecord, 'id' | 'approvalStatus' | 'status'> & { autoApprove?: boolean; approvedBy?: string }): DisposalRecord {
  const list = getDisposals();
  const id = `DSP-2026-${String(list.length + 1).padStart(2, '0')}`;
  const isApproved = data.autoApprove ?? true;

  const created: DisposalRecord = {
    ...data,
    id,
    approvalStatus: isApproved ? 'Disposed' : 'Pending',
    status: isApproved ? 'Disposed' : 'Pending',
    approvedBy: isApproved ? (data.approvedBy || getCurrentUser().name) : undefined,
    certificateNo: `CERT-EWASTE-${Date.now().toString().slice(-6)}`
  };

  saveDisposals([created, ...list]);

  // If approved/disposed immediately, update Asset
  if (isApproved) {
    const asset = getAssetById(data.assetId);
    if (asset) {
      updateAsset(asset.id, {
        status: 'Disposed',
        condition: data.condition || 'Decommissioned',
        timeline: [
          {
            id: `TL-${Date.now()}`,
            date: data.disposalDate || new Date().toISOString().split('T')[0],
            title: 'Asset Disposed & Decommissioned',
            type: 'Disposal',
            description: `Reason: ${data.reason}. Condition: ${data.condition}. Residual value: $${data.residualValue || 0}. Approved by: ${created.approvedBy || 'Management'}. Cert: ${created.certificateNo}`,
            actor: getCurrentUser().name
          },
          ...(asset.timeline || [])
        ]
      });
    }
  }

  return created;
}

export function approveDisposal(id: string, approverName: string): DisposalRecord | undefined {
  const list = getDisposals();
  const record = list.find(d => d.id === id);
  if (record) {
    record.approvalStatus = 'Disposed';
    record.status = 'Disposed';
    record.approvedBy = approverName;
    record.disposalDate = record.disposalDate || new Date().toISOString().split('T')[0];
    record.certificateNo = record.certificateNo || `CERT-EWASTE-${Date.now().toString().slice(-6)}`;
    saveDisposals(list);

    // Set asset status to Disposed & Decommissioned
    const asset = getAssetById(record.assetId);
    if (asset) {
      updateAsset(asset.id, {
        status: 'Disposed',
        condition: record.condition || 'Decommissioned',
        timeline: [
          {
            id: `TL-${Date.now()}`,
            date: record.disposalDate,
            title: 'Asset Disposal Approved & Executed',
            type: 'Disposal',
            description: `Disposal request approved by ${approverName}. Asset written off. Cert: ${record.certificateNo}`,
            actor: approverName
          },
          ...(asset.timeline || [])
        ]
      });
    }
    return record;
  }
  return undefined;
}

export function rejectDisposal(id: string, notes?: string): DisposalRecord | undefined {
  const list = getDisposals();
  const record = list.find(d => d.id === id);
  if (record) {
    record.approvalStatus = 'Rejected';
    record.status = 'Rejected';
    if (notes) record.notes = notes;
    saveDisposals(list);
    return record;
  }
  return undefined;
}

// Vendors API
export function getVendors(): Vendor[] {
  return getStored<Vendor[]>('assetpulse_vendors', mockVendors);
}

// Employees API
export function getEmployees(): Employee[] {
  return getStored<Employee[]>(STORAGE_KEYS.EMPLOYEES, mockEmployees);
}

export function saveEmployees(employees: Employee[]): void {
  setStored(STORAGE_KEYS.EMPLOYEES, employees);
}

export function addEmployee(data: Omit<Employee, 'id' | 'assignedAssetCount'>): Employee {
  const employees = getEmployees();
  const id = `EMP-${100 + employees.length + 1}`;
  const newEmp: Employee = {
    ...data,
    id,
    assignedAssetCount: 0,
    avatar: data.avatar || `https://images.unsplash.com/photo-${1500648767791 + employees.length}?w=150&auto=format&fit=crop&q=80`,
  };
  const updated = [newEmp, ...employees];
  saveEmployees(updated);
  return newEmp;
}

export function updateEmployee(id: string, updates: Partial<Employee>): Employee | undefined {
  const employees = getEmployees();
  const idx = employees.findIndex((e) => e.id === id);
  if (idx === -1) return undefined;

  const updated: Employee = { ...employees[idx], ...updates };
  employees[idx] = updated;
  saveEmployees(employees);
  return updated;
}

export function deleteEmployee(id: string): boolean {
  const employees = getEmployees();
  const filtered = employees.filter((e) => e.id !== id);
  if (filtered.length < employees.length) {
    saveEmployees(filtered);
    return true;
  }
  return false;
}

// Departments API
export function getDepartments(): Department[] {
  return getStored<Department[]>(STORAGE_KEYS.DEPARTMENTS, mockDepartments);
}

export function saveDepartments(departments: Department[]): void {
  setStored(STORAGE_KEYS.DEPARTMENTS, departments);
}

export function addDepartment(data: Omit<Department, 'id' | 'totalAssets'>): Department {
  const departments = getDepartments();
  const id = `DEP-${String(departments.length + 1).padStart(3, '0')}`;
  const newDept: Department = {
    ...data,
    id,
    totalAssets: 0,
  };
  const updated = [...departments, newDept];
  saveDepartments(updated);
  return newDept;
}

export function updateDepartment(id: string, updates: Partial<Department>): Department | undefined {
  const departments = getDepartments();
  const idx = departments.findIndex((d) => d.id === id);
  if (idx === -1) return undefined;

  const updated: Department = { ...departments[idx], ...updates };
  departments[idx] = updated;
  saveDepartments(departments);
  return updated;
}

export function deleteDepartment(id: string): boolean {
  const departments = getDepartments();
  const filtered = departments.filter((d) => d.id !== id);
  if (filtered.length < departments.length) {
    saveDepartments(filtered);
    return true;
  }
  return false;
}

// Gemini AI Chat Assistant Integration
export async function sendChatMessageToAI(message: string, context?: any): Promise<string> {
  try {
    const res = await fetch('/api/gemini/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context }),
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.details || err.error || 'Failed to communicate with AI Assistant');
    }

    const data = await res.json();
    return data.reply;
  } catch (err: any) {
    console.error('sendChatMessageToAI Error:', err);
    return `[AssetPulse AI Assistant Offline / Fallback Response]: I've logged your request: "${message}". Please ensure your GEMINI_API_KEY is configured in the Secrets menu for live AI reasoning.`;
  }
}

// Calculate system stats dynamically
export function calculateStats(): SystemStats {
  const assets = getAssets();
  const complaints = getComplaints();
  const transfers = getTransfers();
  const pms = getPMs();

  return {
    totalAssets: assets.length,
    assignedAssets: assets.filter(a => a.status === 'In Use').length,
    availableAssets: assets.filter(a => a.status === 'Available').length,
    underRepair: assets.filter(a => a.status === 'Under Repair').length,
    warrantyExpiring: assets.filter(a => a.warrantyStatus === 'Expiring Soon').length,
    disposedAssets: assets.filter(a => a.status === 'Disposed').length,
    totalValuation: assets.reduce((sum, a) => sum + (a.currentValue || 0), 0),
    openComplaints: complaints.filter(c => c.status === 'Open' || c.status === 'In Progress').length,
    pendingTransfers: transfers.filter(t => t.status === 'Pending Approval').length,
    upcomingMaintenances: pms.filter(p => p.active).length
  };
}

// ==========================================
// Async REST API Integration Layer
// ==========================================
export async function apiGetMe(): Promise<User | null> {
  const token = getAuthToken();
  if (!token) return null;

  try {
    const res = await fetch('/api/auth/me', {
      headers: getAuthHeaders()
    });
    if (res.ok) {
      const data = await res.json();
      if (data && data.user) {
        setCurrentUser(data.user);
        return data.user;
      }
    } else {
      // Token invalid or expired
      setAuthToken(null);
      localStorage.removeItem(STORAGE_KEYS.USER);
    }
  } catch (err) {
    console.warn('apiGetMe verification failed:', err);
  }
  return null;
}

export async function apiLogout(): Promise<void> {
  try {
    await fetch('/api/auth/logout', {
      method: 'POST',
      headers: getAuthHeaders()
    });
  } catch (err) {
    console.warn('Backend logout call error:', err);
  } finally {
    // Purge authentication tokens and user state
    setAuthToken(null);
    localStorage.removeItem(STORAGE_KEYS.USER);
    sessionStorage.clear();
  }
}

export async function apiFetchUsers(): Promise<User[]> {
  try {
    const res = await fetch('/api/users', { headers: getAuthHeaders() });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        saveUsers(data);
        return data;
      }
    }
  } catch (err) {
    console.warn('Backend API fetch error:', err);
  }
  return getUsers();
}

export async function apiFetchAssets(): Promise<Asset[]> {
  try {
    const res = await fetch('/api/assets', { headers: getAuthHeaders() });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        saveAssets(data);
        return data;
      }
    }
  } catch (err) {
    console.warn('Backend API fetch error:', err);
  }
  return getAssets();
}

export async function apiCreateAsset(assetData: Omit<Asset, 'id' | 'qrCode' | 'timeline'>): Promise<Asset> {
  const localCreated = addAsset(assetData);
  try {
    await fetch('/api/assets', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(localCreated)
    });
  } catch (err) {
    console.warn('Backend asset creation sync failed:', err);
  }
  return localCreated;
}

export async function apiFetchDepartments(): Promise<Department[]> {
  try {
    const res = await fetch('/api/departments', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getDepartments();
}

export async function apiFetchEmployees(): Promise<Employee[]> {
  try {
    const res = await fetch('/api/employees', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getEmployees();
}

export async function apiFetchVendors(): Promise<Vendor[]> {
  try {
    const res = await fetch('/api/vendors', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getVendors();
}

export async function apiFetchTransfers(): Promise<AssignmentTransfer[]> {
  try {
    const res = await fetch('/api/transfers', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getTransfers();
}

export async function apiFetchComplaints(): Promise<ComplaintTicket[]> {
  try {
    const res = await fetch('/api/complaints', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getComplaints();
}

export async function apiFetchRepairs(): Promise<RepairRecord[]> {
  try {
    const res = await fetch('/api/repairs', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getRepairs();
}

export async function apiFetchMaintenance(): Promise<PreventiveMaintenance[]> {
  try {
    const res = await fetch('/api/maintenance', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getPMs();
}

export async function apiFetchWarranties(): Promise<WarrantyRecord[]> {
  try {
    const res = await fetch('/api/warranties', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getWarranties();
}

export async function apiFetchAudits(): Promise<AssetAudit[]> {
  try {
    const res = await fetch('/api/audits', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getAudits();
}

export async function apiFetchDisposals(): Promise<DisposalRecord[]> {
  try {
    const res = await fetch('/api/disposals', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API error:', err);
  }
  return getDisposals();
}

export async function apiUpdateUser(id: string, updates: Partial<User>): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const res = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
      body: JSON.stringify(updates)
    });
    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data.error || 'Failed to update user.' };
    }
    updateUserRecord(id, updates);
    return { success: true, user: data };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error updating user.' };
  }
}

export async function apiDeleteUser(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch(`/api/users/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data.error || 'Failed to delete user.' };
    }
    deleteUserRecord(id);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || 'Network error deleting user.' };
  }
}

export async function apiFetchActivityLogs(): Promise<ActivityLog[]> {
  try {
    const res = await fetch('/api/activity-logs', { headers: getAuthHeaders() });
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Backend API activity-logs fetch error:', err);
  }
  return getStored<ActivityLog[]>('assetpulse_activity_logs', mockActivityLogs);
}

