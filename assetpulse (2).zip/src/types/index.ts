export type Role = 'super_admin' | 'asset_manager' | 'technician' | 'employee';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  avatar: string;
  departmentId: string;
  departmentName: string;
  title: string;
  phone: string;
  status?: 'Active' | 'Inactive';
}

export type AssetStatus = 
  | 'In Use' 
  | 'Available' 
  | 'Under Repair' 
  | 'Pending Transfer' 
  | 'Maintenance' 
  | 'Disposed';

export type AssetCondition = 
  | 'New' 
  | 'Good' 
  | 'Fair' 
  | 'Needs Repair' 
  | 'Decommissioned';

export type AssetCategory = 
  | 'Laptops & Desktops' 
  | 'Monitors & Displays' 
  | 'Networking & Servers' 
  | 'Mobile & Tablets' 
  | 'Office Equipment' 
  | 'Peripherals';

export interface LifecycleEvent {
  id: string;
  date: string;
  title: string;
  type: 'Purchase' | 'Assignment' | 'Transfer' | 'Maintenance' | 'Repair' | 'Audit' | 'Disposal';
  description: string;
  actor: string;
  badgeColor?: string;
}

export interface Asset {
  id: string;
  tag: string;
  name: string;
  category: AssetCategory;
  brand: string;
  model: string;
  serialNumber: string;
  departmentId: string;
  departmentName: string;
  assignedEmployeeId?: string;
  assignedEmployeeName?: string;
  location: string;
  status: AssetStatus;
  condition: AssetCondition;
  purchaseDate: string;
  purchaseCost: number;
  currentValue: number;
  salvageValue: number;
  expectedLifespanYears: number;
  warrantyExpiry: string;
  warrantyVendor: string;
  warrantyStatus: 'Active' | 'Expiring Soon' | 'Expired' | 'None';
  qrCode: string;
  specifications: Record<string, string>;
  notes?: string;
  timeline: LifecycleEvent[];
}

export interface Department {
  id: string;
  code: string;
  name: string;
  headName: string;
  location: string;
  totalAssets: number;
  budgetAllocated: number;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: string;
  departmentId: string;
  departmentName: string;
  location: string;
  phone: string;
  avatar: string;
  assignedAssetCount: number;
  status: 'Active' | 'On Leave' | 'Terminated';
}

export interface Vendor {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  category: string;
  rating: number;
  activeContracts: number;
  linkedAssetsCount: number;
  slaResponseHours: number;
}

export interface AssignmentTransfer {
  id: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  type: 'Checkout' | 'Checkin' | 'Transfer';
  fromEmployee?: string;
  toEmployee?: string;
  fromDept?: string;
  toDept?: string;
  fromLocation?: string;
  toLocation?: string;
  requestedBy: string;
  requestedDate: string;
  status: 'Pending Approval' | 'Approved' | 'Rejected' | 'Completed';
  reason: string;
  notes?: string;
}

export interface ComplaintTicket {
  id: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  raisedBy: string;
  raisedByEmail: string;
  department: string;
  title: string;
  description: string; // issue
  priority: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'Assigned' | 'In Progress' | 'Diagnosis' | 'Resolved' | 'Closed';
  assignedTech?: string;
  diagnosis?: string;
  repairAction?: string;
  cost?: number;
  notes?: string;
  createdAt: string;
  resolvedAt?: string;
  resolutionNotes?: string;
}

export interface RepairRecord {
  id: string;
  ticketId?: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  vendorName: string;
  technicianName: string;
  issueDescription: string; // issue
  diagnosis?: string;
  repairAction?: string;
  priority?: 'Low' | 'Medium' | 'High' | 'Critical';
  repairCost: number;
  partsCost?: number;
  laborCost?: number;
  downtimeDays: number;
  status: 'Scheduled' | 'In Diagnosis' | 'In Repair' | 'Parts Awaiting' | 'Completed' | 'Cancelled';
  repairvsReplaceScore: number; // 0 to 100 percentage
  recommendation: 'Repair Recommended' | 'Consider Replacement' | 'Replace Immediately';
  startDate: string;
  targetEndDate?: string;
  endDate?: string;
  notes?: string;
}

export interface PreventiveMaintenance {
  id: string;
  assetId?: string;
  assetName?: string;
  assetTag?: string;
  title: string;
  category: AssetCategory | 'All';
  priority?: 'Low' | 'Medium' | 'High' | 'Critical';
  frequency: 'Monthly' | 'Quarterly' | 'Bi-Annually' | 'Annual';
  nextDueDate: string;
  lastPerformedDate?: string;
  assignedTech: string;
  vendorName?: string;
  checklist: { id: string; task: string; completed: boolean }[];
  active: boolean;
  status?: 'Upcoming' | 'Due Today' | 'Overdue' | 'Completed';
  estimatedCost?: number;
  actualCost?: number;
  notes?: string;
  diagnosis?: string;
  repairAction?: string;
}

export interface WarrantyRecord {
  id: string;
  assetId: string;
  assetName: string;
  vendorName: string;
  policyNumber: string;
  startDate: string;
  expiryDate: string;
  coverageDetails: string;
  claimCount: number;
  status: 'Active' | 'Expiring Soon' | 'Expired';
}

export interface AuditItem {
  assetId: string;
  assetName: string;
  assetTag: string;
  category: string;
  expectedLocation: string;
  assignedEmployeeName?: string;
  status: 'Found' | 'Missing' | 'Damaged' | 'Pending';
  notes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface AssetAudit {
  id: string;
  campaignName: string;
  targetDepartment: string;
  targetLocation: string;
  auditorName: string;
  startDate: string;
  endDate: string;
  status: 'Draft' | 'In Progress' | 'Completed';
  totalExpected: number;
  totalScanned: number;
  items: AuditItem[];
  discrepanciesCount?: number;
  notes?: string;
  completedAt?: string;
}

export interface DisposalRecord {
  id: string;
  assetId: string;
  assetName: string;
  assetTag: string;
  reason: 'Obsolescence' | 'Beyond Economical Repair' | 'Lost/Stolen' | 'Decommissioned' | 'Sold' | 'Donated';
  disposalDate: string;
  condition: AssetCondition;
  requestedBy: string;
  approvedBy?: string;
  approvalStatus: 'Pending' | 'Approved' | 'Disposed' | 'Rejected';
  status?: 'Pending' | 'Approved' | 'Disposed' | 'Rejected';
  residualValue?: number;
  saleOrRecycleAmount?: number;
  certificateNo?: string;
  notes?: string;
}

export interface ActivityLog {
  id: string;
  userId?: string;
  userName?: string;
  action: string;
  entityType: string;
  entityId: string;
  details?: string;
  ipAddress?: string;
  createdAt: string;
}

export interface SystemStats {
  totalAssets: number;
  assignedAssets: number;
  availableAssets: number;
  underRepair: number;
  warrantyExpiring: number;
  disposedAssets: number;
  totalValuation: number;
  openComplaints: number;
  pendingTransfers: number;
  upcomingMaintenances: number;
}
