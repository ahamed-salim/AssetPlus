import React from 'react';
import { AssetStatus, AssetCondition } from '../../types';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'neutral';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  className = ''
}) => {
  const variantStyles = {
    default: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700',
    success: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60',
    warning: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800/60',
    danger: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800/60',
    info: 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border-sky-200 dark:border-sky-800/60',
    purple: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800/60',
    neutral: 'bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700'
  };

  const sizeStyles = {
    sm: 'text-xs px-2 py-0.5 rounded-md font-medium border',
    md: 'text-xs px-2.5 py-1 rounded-md font-semibold border',
    lg: 'text-sm px-3 py-1.5 rounded-lg font-semibold border'
  };

  return (
    <span className={`inline-flex items-center gap-1.2 whitespace-nowrap ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}>
      {children}
    </span>
  );
};

export function getStatusBadge(status: AssetStatus) {
  switch (status) {
    case 'In Use':
      return <Badge variant="success">● In Use</Badge>;
    case 'Available':
      return <Badge variant="info">● Available</Badge>;
    case 'Under Repair':
      return <Badge variant="warning">● Under Repair</Badge>;
    case 'Pending Transfer':
      return <Badge variant="purple">● Pending Transfer</Badge>;
    case 'Maintenance':
      return <Badge variant="warning">● Maintenance</Badge>;
    case 'Disposed':
      return <Badge variant="danger">● Disposed</Badge>;
    default:
      return <Badge variant="neutral">{status}</Badge>;
  }
}

export function getConditionBadge(condition: AssetCondition) {
  switch (condition) {
    case 'New':
      return <Badge variant="success">New</Badge>;
    case 'Good':
      return <Badge variant="info">Good</Badge>;
    case 'Fair':
      return <Badge variant="warning">Fair</Badge>;
    case 'Needs Repair':
      return <Badge variant="danger">Needs Repair</Badge>;
    case 'Decommissioned':
      return <Badge variant="neutral">Decommissioned</Badge>;
    default:
      return <Badge variant="neutral">{condition}</Badge>;
  }
}
