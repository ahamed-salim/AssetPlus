import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { Download, Printer, QrCode, Check, Copy, FileCode2 } from 'lucide-react';

interface QRCodeViewProps {
  value: string;
  assetTag: string;
  assetName: string;
  departmentName?: string;
  location?: string;
  serialNumber?: string;
  size?: number;
  showActions?: boolean;
}

export const QRCodeView: React.FC<QRCodeViewProps> = ({
  value,
  assetTag,
  assetName,
  departmentName,
  location,
  serialNumber,
  size = 150,
  showActions = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const printRef = useRef<HTMLDivElement>(null);
  const [svgString, setSvgString] = useState<string>('');
  const [dataUrl, setDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (canvasRef.current && value) {
      QRCode.toCanvas(canvasRef.current, value, {
        width: size,
        margin: 1,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
        errorCorrectionLevel: 'M'
      }, (err) => {
        if (!err && canvasRef.current) {
          setDataUrl(canvasRef.current.toDataURL('image/png'));
        }
      });

      QRCode.toString(value, {
        type: 'svg',
        width: size,
        margin: 1,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        }
      }, (err, string) => {
        if (!err && string) {
          setSvgString(string);
        }
      });
    }
  }, [value, size]);

  const handleDownloadPNG = () => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.download = `PropertyTag_${assetTag.replace(/[^a-zA-Z0-9-]/g, '_')}.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleDownloadSVG = () => {
    if (!svgString) return;
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `PropertyTag_${assetTag.replace(/[^a-zA-Z0-9-]/g, '_')}.svg`;
    link.href = url;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank', 'width=650,height=650');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Asset Tag - ${assetTag}</title>
          <style>
            @page { size: auto; margin: 10mm; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              padding: 20px;
              display: flex;
              justify-content: center;
              background-color: #f8fafc;
            }
            .tag-card {
              width: 320px;
              border: 2px solid #0f172a;
              border-radius: 12px;
              padding: 16px;
              background: #ffffff;
              text-align: center;
              box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }
            .tag-header {
              font-size: 11px;
              font-weight: 800;
              letter-spacing: 1.5px;
              color: #2563eb;
              text-transform: uppercase;
              border-bottom: 1px solid #e2e8f0;
              padding-bottom: 6px;
              margin-bottom: 12px;
            }
            .qr-container {
              display: flex;
              justify-content: center;
              margin: 8px 0;
            }
            .qr-container img {
              width: 140px;
              height: 140px;
            }
            .tag-code {
              font-family: ui-monospace, monospace;
              font-size: 18px;
              font-weight: 800;
              color: #0f172a;
              margin-top: 6px;
              letter-spacing: 1px;
            }
            .tag-name {
              font-size: 13px;
              font-weight: 700;
              color: #334155;
              margin-top: 4px;
            }
            .tag-meta {
              font-size: 10px;
              color: #64748b;
              margin-top: 8px;
              padding-top: 8px;
              border-top: 1px dashed #cbd5e1;
            }
          </style>
        </head>
        <body>
          <div class="tag-card">
            <div class="tag-header">AssetPulse Property Tag</div>
            <div class="qr-container">
              <img src="${dataUrl}" alt="QR Code" />
            </div>
            <div class="tag-code">${assetTag}</div>
            <div class="tag-name">${assetName}</div>
            ${departmentName || location ? `<div class="tag-meta">${departmentName || ''} ${location ? '• ' + location : ''} ${serialNumber ? '<br/>S/N: ' + serialNumber : ''}</div>` : ''}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(() => window.close(), 500);
            }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="flex flex-col items-center bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700/80">
      {/* Property Tag Render Container */}
      <div ref={printRef} className="p-3.5 bg-white rounded-xl shadow-xs border border-slate-200 dark:border-slate-700 flex flex-col items-center">
        <canvas ref={canvasRef} className="rounded-md" />
        <div className="mt-2 text-center">
          <p className="text-sm font-extrabold tracking-widest text-slate-900 font-mono">
            {assetTag}
          </p>
          <p className="text-xs font-semibold text-slate-600 max-w-[190px] truncate mt-0.5">
            {assetName}
          </p>
          {(departmentName || location) && (
            <p className="text-[10px] text-slate-400 mt-0.5 truncate max-w-[190px]">
              {departmentName} {location ? `• ${location}` : ''}
            </p>
          )}
        </div>
      </div>

      {showActions && (
        <div className="mt-3.5 flex flex-wrap items-center justify-center gap-2 w-full">
          <button
            onClick={handleDownloadPNG}
            className="flex-1 min-w-[100px] inline-flex items-center justify-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-xs"
            title="Download QR code image as PNG"
          >
            <Download className="w-3.5 h-3.5" />
            <span>PNG</span>
          </button>

          <button
            onClick={handleDownloadSVG}
            className="flex-1 min-w-[100px] inline-flex items-center justify-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors shadow-xs"
            title="Download QR code vector as SVG"
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>SVG</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex-1 min-w-[100px] inline-flex items-center justify-center gap-1 text-[11px] font-bold px-2.5 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 transition-colors shadow-xs"
            title="Print printable property tag"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Tag</span>
          </button>

          <button
            onClick={handleCopyCode}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
            title="Copy QR Code String"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      )}
    </div>
  );
};

