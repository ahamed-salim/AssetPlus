import React from 'react';
import { 
  LayoutDashboard, 
  Box, 
  Users, 
  Building2, 
  ArrowLeftRight, 
  QrCode, 
  TicketCheck, 
  Wrench, 
  ShieldAlert, 
  ClipboardCheck, 
  Trash2, 
  BarChart3, 
  Bot,
  Activity,
  Layers,
  ShieldCheck,
  UserCheck,
  LogOut
} from 'lucide-react';
import { User } from '../../types';

export type ActiveTab = 
  | 'dashboard' 
  | 'assets' 
  | 'employees' 
  | 'users'
  | 'profile'
  | 'vendors' 
  | 'transfers' 
  | 'qr_scanner' 
  | 'complaints' 
  | 'repairs' 
  | 'warranty' 
  | 'audit' 
  | 'disposal' 
  | 'reports'
  | 'ai_assistant';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  currentUser: User;
  pendingTransfersCount?: number;
  openTicketsCount?: number;
  onLogout?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  pendingTransfersCount = 0,
  openTicketsCount = 0,
  onLogout
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'assets', label: 'Assets Repository', icon: Box },
    { id: 'employees', label: 'Employees & Depts', icon: Users },
    { id: 'users', label: 'User Access & Roles', icon: ShieldCheck },
    { id: 'profile', label: 'My Profile & Account', icon: UserCheck },
    { 
      id: 'transfers', 
      label: 'Assignments & Transfers', 
      icon: ArrowLeftRight,
      badge: pendingTransfersCount > 0 ? pendingTransfersCount : undefined
    },
    { id: 'qr_scanner', label: 'QR Generator & Scan', icon: QrCode },
    { 
      id: 'complaints', 
      label: 'Complaints & Tickets', 
      icon: TicketCheck,
      badge: openTicketsCount > 0 ? openTicketsCount : undefined
    },
    { id: 'repairs', label: 'Repairs & Maintenance', icon: Wrench },
    { id: 'warranty', label: 'Warranty & Claims', icon: ShieldAlert },
    { id: 'audit', label: 'Asset Audit Campaigns', icon: ClipboardCheck },
    { id: 'disposal', label: 'Asset Disposal', icon: Trash2 },
    { id: 'reports', label: 'Reports & Depreciation', icon: BarChart3 },
  ];

  return (
    <aside className="w-64 border-r border-slate-200 dark:border-slate-800 bg-slate-900 text-slate-100 flex flex-col h-screen sticky top-0 shrink-0 z-40 transition-colors">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-800 flex flex-col gap-1">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-blue-600 text-white shadow-md">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5 font-mono">
              AssetPulse
            </h1>
            <span className="text-[10px] font-semibold text-blue-400 uppercase tracking-widest block">
              ENTERPRISE EAM
            </span>
          </div>
        </div>
        <p className="text-[11px] text-slate-400 mt-2 italic font-medium leading-tight">
          "Know Every Asset. Control Every Lifecycle."
        </p>
      </div>

      {/* Navigation Menu */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        <div className="px-3 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-500">
          Core Modules
        </div>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id as ActiveTab)}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span className={`px-1.5 py-0.5 text-[10px] rounded-full font-bold ${
                  isActive ? 'bg-white text-blue-700' : 'bg-blue-950 text-blue-400 border border-blue-800'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom AI Copilot Quick Button & Logout */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/60 space-y-2">
        <button
          onClick={() => onSelectTab('ai_assistant')}
          className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg border text-xs font-bold transition-all ${
            activeTab === 'ai_assistant'
              ? 'bg-indigo-600 text-white border-indigo-500'
              : 'border-slate-800 bg-slate-900 text-indigo-300 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <Bot className="w-4 h-4 text-indigo-400" />
          <span>AssetPulse AI Copilot</span>
        </button>

        {onLogout && (
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-800/80 bg-rose-950/20 text-rose-400 hover:bg-rose-950/50 hover:text-rose-300 transition-all text-xs font-bold"
            title="Sign Out of Workspace"
          >
            <LogOut className="w-4 h-4 text-rose-500" />
            <span>Sign Out</span>
          </button>
        )}
      </div>
    </aside>
  );
};
