import React, { useState } from 'react';
import { 
  Search, 
  Bot, 
  Bell, 
  UserCheck, 
  ChevronDown, 
  ShieldCheck, 
  Wrench, 
  User as UserIcon,
  Briefcase,
  LogOut
} from 'lucide-react';
import { User, Role } from '../../types';
import { mockUsers } from '../../data/mockData';

interface HeaderProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  onOpenAIAssistant: () => void;
  onSearchChange?: (term: string) => void;
  onNavigateToProfile?: () => void;
  onLogout?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onUserChange,
  onOpenAIAssistant,
  onSearchChange,
  onNavigateToProfile,
  onLogout
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const getRoleIcon = (role: Role) => {
    switch (role) {
      case 'super_admin': return <ShieldCheck className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
      case 'asset_manager': return <Briefcase className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
      case 'technician': return <Wrench className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'employee': return <UserIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
    }
  };

  const getRoleBadge = (role: Role) => {
    switch (role) {
      case 'super_admin': return 'Super Admin';
      case 'asset_manager': return 'Asset Manager';
      case 'technician': return 'Technician';
      case 'employee': return 'Employee';
    }
  };

  return (
    <header className="h-16 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between transition-colors">
      {/* Global Search Bar */}
      <div className="relative w-72 md:w-96">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          placeholder="Search assets, serials, tickets, employees..."
          onChange={(e) => onSearchChange?.(e.target.value)}
          className="w-full pl-9 pr-4 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:border-blue-500 transition-all"
        />
      </div>

      {/* Top Right Actions */}
      <div className="flex items-center gap-3">
        {/* Role Switcher Pill */}
        <div className="relative">
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100/70 dark:bg-slate-800/80 hover:bg-slate-200/70 dark:hover:bg-slate-700 transition-colors text-slate-800 dark:text-slate-200"
            title="Switch User Role to test RBAC views"
          >
            {getRoleIcon(currentUser.role)}
            <span>{getRoleBadge(currentUser.role)}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {showRoleMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl py-2 z-50">
              <div className="px-3 py-1.5 border-b border-slate-100 dark:border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Simulate Role Context (RBAC)
              </div>
              {mockUsers.map((u) => (
                <button
                  key={u.id}
                  onClick={() => {
                    onUserChange(u);
                    setShowRoleMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 flex items-center justify-between text-xs hover:bg-slate-50 dark:hover:bg-slate-800/70 transition-colors ${
                    currentUser.id === u.id ? 'bg-blue-50/60 dark:bg-blue-950/40 font-bold text-blue-600 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {getRoleIcon(u.role)}
                    <div>
                      <p className="font-semibold">{u.name}</p>
                      <p className="text-[10px] text-slate-400">{u.title}</p>
                    </div>
                  </div>
                  {currentUser.id === u.id && <UserCheck className="w-4 h-4 text-blue-600" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* AI Assistant Drawer Trigger */}
        <button
          onClick={onOpenAIAssistant}
          className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-700 hover:to-indigo-700 transition-all shadow-xs"
        >
          <Bot className="w-4 h-4" />
          <span className="hidden sm:inline">AI Assistant</span>
        </button>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500" />
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl p-3 z-50">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100">Notifications</span>
                <span className="text-[10px] bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 font-bold px-1.5 py-0.5 rounded">3 New</span>
              </div>
              <div className="mt-2 space-y-2 text-xs">
                <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 text-amber-800 dark:text-amber-300">
                  <p className="font-semibold">Warranty Expiring Soon</p>
                  <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-0.5">Dell Monitor U3223QE warranty expires in 30 days.</p>
                </div>
                <div className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-900/40 text-indigo-800 dark:text-indigo-300">
                  <p className="font-semibold">Transfer Request Pending</p>
                  <p className="text-[11px] text-indigo-700 dark:text-indigo-400 mt-0.5">Michael Chang requested checkout for Server AST-2026-007.</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Avatar & Profile Dropdown */}
        <div className="relative flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
          <button 
            onClick={() => {
              setShowProfileMenu(!showProfileMenu);
              setShowRoleMenu(false);
              setShowNotifications(false);
            }}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity cursor-pointer group"
            title="User Account & Profile Menu"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:ring-2 group-hover:ring-blue-500 transition-all"
            />
            <div className="hidden lg:block text-left">
              <p className="text-xs font-bold text-slate-900 dark:text-slate-100 leading-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {currentUser.name}
              </p>
              <p className="text-[10px] text-slate-400 leading-tight truncate max-w-[110px]">
                {currentUser.departmentName || 'AssetPulse User'}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden lg:block" />
          </button>

          {/* Quick Direct Logout Button */}
          {onLogout && (
            <button
              onClick={onLogout}
              className="p-2 rounded-lg text-rose-500 hover:text-rose-700 dark:text-rose-400 dark:hover:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors ml-1"
              title="Sign Out of AssetPulse"
            >
              <LogOut className="w-4 h-4" />
            </button>
          )}

          {/* User Profile Dropdown Menu */}
          {showProfileMenu && (
            <div className="absolute right-0 top-11 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl py-2 z-50 animate-in fade-in slide-in-from-top-2">
              <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                    {currentUser.name}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate">
                    {currentUser.email}
                  </p>
                  <div className="mt-1 inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-900">
                    {getRoleIcon(currentUser.role)}
                    <span className="capitalize">{getRoleBadge(currentUser.role)}</span>
                  </div>
                </div>
              </div>

              <div className="p-1 space-y-0.5">
                <button
                  onClick={() => {
                    setShowProfileMenu(false);
                    onNavigateToProfile?.();
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <UserIcon className="w-4 h-4 text-blue-500" />
                  <span>My Profile & Account</span>
                </button>
              </div>

              {onLogout && (
                <div className="p-1 border-t border-slate-100 dark:border-slate-800 mt-1">
                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      onLogout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-bold rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/60 transition-colors"
                  >
                    <LogOut className="w-4 h-4 text-rose-500" />
                    <span>Sign Out / Logout</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
