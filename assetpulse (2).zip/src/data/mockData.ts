import {
  User,
  Department,
  Employee,
  Vendor,
  Asset,
  AssignmentTransfer,
  ComplaintTicket,
  RepairRecord,
  PreventiveMaintenance,
  WarrantyRecord,
  AssetAudit,
  DisposalRecord,
  ActivityLog,
  SystemStats
} from '../types';

export const mockUsers: User[] = [
  {
    id: 'USR-001',
    name: 'Eleanor Vance',
    email: 'eleanor.vance@assetpulse.io',
    role: 'super_admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    departmentId: 'DEP-001',
    departmentName: 'IT Operations & Security',
    title: 'VP of Enterprise Technology',
    phone: '+1 (555) 019-2831'
  },
  {
    id: 'USR-002',
    name: 'Marcus Chen',
    email: 'marcus.chen@assetpulse.io',
    role: 'asset_manager',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    departmentId: 'DEP-001',
    departmentName: 'IT Operations & Security',
    title: 'Lead Asset Operations Manager',
    phone: '+1 (555) 018-9421'
  },
  {
    id: 'USR-003',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@assetpulse.io',
    role: 'technician',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    departmentId: 'DEP-001',
    departmentName: 'IT Operations & Security',
    title: 'Senior Systems & Hardware Engineer',
    phone: '+1 (555) 017-3829'
  },
  {
    id: 'USR-004',
    name: 'Alex Rivera',
    email: 'alex.rivera@assetpulse.io',
    role: 'employee',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    title: 'Staff Product Designer',
    phone: '+1 (555) 016-5912'
  }
];

export const mockDepartments: Department[] = [
  {
    id: 'DEP-001',
    code: 'IT-OPS',
    name: 'IT Operations & Security',
    headName: 'Eleanor Vance',
    location: 'Building A, Floor 4',
    totalAssets: 48,
    budgetAllocated: 250000
  },
  {
    id: 'DEP-002',
    code: 'PD-UX',
    name: 'Product Design & UX',
    headName: 'David Kross',
    location: 'Building B, Floor 2',
    totalAssets: 32,
    budgetAllocated: 140000
  },
  {
    id: 'DEP-003',
    code: 'ENG',
    name: 'Software Engineering',
    headName: 'Priya Sharma',
    location: 'Building A, Floor 3',
    totalAssets: 86,
    budgetAllocated: 420000
  },
  {
    id: 'DEP-004',
    code: 'FIN-HR',
    name: 'Finance & Human Resources',
    headName: 'Robert Sterling',
    location: 'Building A, Floor 1',
    totalAssets: 24,
    budgetAllocated: 95000
  },
  {
    id: 'DEP-005',
    code: 'MKT-SLS',
    name: 'Sales & Global Marketing',
    headName: 'Jessica Taylor',
    location: 'Building B, Floor 3',
    totalAssets: 41,
    budgetAllocated: 180000
  }
];

export const mockEmployees: Employee[] = [
  {
    id: 'EMP-101',
    name: 'Alex Rivera',
    email: 'alex.rivera@assetpulse.io',
    role: 'Staff Product Designer',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    location: 'Building B - Desk 204',
    phone: '+1 (555) 016-5912',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 3,
    status: 'Active'
  },
  {
    id: 'EMP-102',
    name: 'Priya Sharma',
    email: 'priya.sharma@assetpulse.io',
    role: 'VP of Engineering',
    departmentId: 'DEP-003',
    departmentName: 'Software Engineering',
    location: 'Building A - Desk 310',
    phone: '+1 (555) 019-4820',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 2,
    status: 'Active'
  },
  {
    id: 'EMP-103',
    name: 'David Kross',
    email: 'david.kross@assetpulse.io',
    role: 'Head of Design',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    location: 'Building B - Desk 201',
    phone: '+1 (555) 012-3392',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 2,
    status: 'Active'
  },
  {
    id: 'EMP-104',
    name: 'Michael Chang',
    email: 'michael.chang@assetpulse.io',
    role: 'Senior Backend Architect',
    departmentId: 'DEP-003',
    departmentName: 'Software Engineering',
    location: 'Building A - Desk 305',
    phone: '+1 (555) 014-8812',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 3,
    status: 'Active'
  },
  {
    id: 'EMP-105',
    name: 'Jessica Taylor',
    email: 'jessica.taylor@assetpulse.io',
    role: 'Sales Director',
    departmentId: 'DEP-005',
    departmentName: 'Sales & Global Marketing',
    location: 'Building B - Desk 312',
    phone: '+1 (555) 018-2210',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 2,
    status: 'Active'
  },
  {
    id: 'EMP-106',
    name: 'Robert Sterling',
    email: 'robert.sterling@assetpulse.io',
    role: 'Finance Controller',
    departmentId: 'DEP-004',
    departmentName: 'Finance & Human Resources',
    location: 'Building A - Desk 102',
    phone: '+1 (555) 011-9023',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    assignedAssetCount: 1,
    status: 'Active'
  }
];

export const mockVendors: Vendor[] = [
  {
    id: 'VND-001',
    name: 'Apple Enterprise Direct',
    contactPerson: 'Clara Oswald',
    email: 'enterprise@apple.com',
    phone: '+1 (800) 692-7753',
    category: 'Laptops & Mobile Hardware',
    rating: 4.9,
    activeContracts: 3,
    linkedAssetsCount: 42,
    slaResponseHours: 4
  },
  {
    id: 'VND-002',
    name: 'Dell Commercial Solutions',
    contactPerson: 'Gordon Bennett',
    email: 'support@dell-enterprise.com',
    phone: '+1 (800) 456-3355',
    category: 'Displays & Workstations',
    rating: 4.6,
    activeContracts: 2,
    linkedAssetsCount: 38,
    slaResponseHours: 8
  },
  {
    id: 'VND-003',
    name: 'Cisco Systems Global',
    contactPerson: 'Marcus Brody',
    email: 'tac@cisco.com',
    phone: '+1 (800) 553-6387',
    category: 'Network & Server Infrastructure',
    rating: 4.8,
    activeContracts: 4,
    linkedAssetsCount: 15,
    slaResponseHours: 2
  },
  {
    id: 'VND-004',
    name: 'Herman Miller Workspaces',
    contactPerson: 'Laura Croft',
    email: 'commercial@hermanmiller.com',
    phone: '+1 (888) 443-4357',
    category: 'Office Furniture & Ergonomics',
    rating: 4.7,
    activeContracts: 1,
    linkedAssetsCount: 28,
    slaResponseHours: 24
  }
];

export const mockAssets: Asset[] = [
  {
    id: 'AST-2026-001',
    tag: 'AP-99201',
    name: 'MacBook Pro 16" M3 Max (64GB / 2TB)',
    category: 'Laptops & Desktops',
    brand: 'Apple',
    model: 'MacBookPro18,2 (2024)',
    serialNumber: 'C02G9981MD6R',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    assignedEmployeeId: 'EMP-101',
    assignedEmployeeName: 'Alex Rivera',
    location: 'Building B - Desk 204',
    status: 'In Use',
    condition: 'Good',
    purchaseDate: '2024-03-15',
    purchaseCost: 3899,
    currentValue: 2950,
    salvageValue: 600,
    expectedLifespanYears: 4,
    warrantyExpiry: '2027-03-15',
    warrantyVendor: 'Apple Enterprise Direct',
    warrantyStatus: 'Active',
    qrCode: 'AP-99201-AST-2026-001-APPLE-MBP16',
    specifications: {
      Processor: 'Apple M3 Max (16-Core CPU, 40-Core GPU)',
      Memory: '64 GB Unified RAM',
      Storage: '2 TB NVMe SSD',
      Display: '16.2-inch Liquid Retina XDR (3456 x 2234)',
      OS: 'macOS Sequoia 15.1'
    },
    notes: 'Primary workstation assigned for high-fidelity 3D and Figma rendering.',
    timeline: [
      {
        id: 'TL-01',
        date: '2024-03-15',
        title: 'Asset Onboarded',
        type: 'Purchase',
        description: 'Purchased via Apple Enterprise Direct PO #98211 for $3,899.00',
        actor: 'Marcus Chen'
      },
      {
        id: 'TL-02',
        date: '2024-03-18',
        title: 'Assigned to Alex Rivera',
        type: 'Assignment',
        description: 'Checked out to Alex Rivera for Design & Prototyping duties.',
        actor: 'Marcus Chen'
      },
      {
        id: 'TL-03',
        date: '2025-06-10',
        title: 'Annual Physical Audit',
        type: 'Audit',
        description: 'Verified present at Building B - Desk 204 with QR Scan. Condition: Good.',
        actor: 'Sarah Jenkins'
      }
    ]
  },
  {
    id: 'AST-2026-002',
    tag: 'AP-99202',
    name: 'Dell UltraSharp 32" 4K USB-C Hub Monitor (U3223QE)',
    category: 'Monitors & Displays',
    brand: 'Dell',
    model: 'U3223QE PremierColor',
    serialNumber: 'CN-09812A-72811',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    assignedEmployeeId: 'EMP-101',
    assignedEmployeeName: 'Alex Rivera',
    location: 'Building B - Desk 204',
    status: 'In Use',
    condition: 'New',
    purchaseDate: '2024-04-01',
    purchaseCost: 920,
    currentValue: 780,
    salvageValue: 100,
    expectedLifespanYears: 5,
    warrantyExpiry: '2026-09-10',
    warrantyVendor: 'Dell Commercial Solutions',
    warrantyStatus: 'Expiring Soon',
    qrCode: 'AP-99202-AST-2026-002-DELL-U3223QE',
    specifications: {
      Resolution: '3840 x 2160 at 60Hz (IPS Black)',
      Connectivity: 'USB-C (90W PD), DisplayPort 1.4, HDMI 2.0, RJ45 Ethernet',
      ColorSpace: '100% sRGB, 98% DCI-P3'
    },
    timeline: [
      {
        id: 'TL-04',
        date: '2024-04-01',
        title: 'Asset Onboarded',
        type: 'Purchase',
        description: 'Received under Dell Master Supply Agreement.',
        actor: 'Marcus Chen'
      },
      {
        id: 'TL-05',
        date: '2024-04-03',
        title: 'Assigned to Alex Rivera',
        type: 'Assignment',
        description: 'Dual monitor desk setup configuration completed.',
        actor: 'Marcus Chen'
      }
    ]
  },
  {
    id: 'AST-2026-003',
    tag: 'AP-99203',
    name: 'Cisco Catalyst 9300 48-Port PoE+ Switch',
    category: 'Networking & Servers',
    brand: 'Cisco',
    model: 'C9300-48P-A',
    serialNumber: 'FOC2419L0P1',
    departmentId: 'DEP-001',
    departmentName: 'IT Operations & Security',
    assignedEmployeeId: undefined,
    assignedEmployeeName: undefined,
    location: 'Building A - Server Room 102 (Rack A4)',
    status: 'In Use',
    condition: 'Good',
    purchaseDate: '2023-01-10',
    purchaseCost: 6500,
    currentValue: 4100,
    salvageValue: 800,
    expectedLifespanYears: 7,
    warrantyExpiry: '2028-01-10',
    warrantyVendor: 'Cisco Systems Global',
    warrantyStatus: 'Active',
    qrCode: 'AP-99203-AST-2026-003-CISCO-C9300',
    specifications: {
      Ports: '48 x 1G PoE+ (437W PoE Budget)',
      Uplink: 'Modular Uplinks (4 x 10G SFP+)',
      Throughput: '256 Gbps'
    },
    timeline: [
      {
        id: 'TL-06',
        date: '2023-01-10',
        title: 'Server Room Installation',
        type: 'Purchase',
        description: 'Rack mounted and configured in Server Room 102.',
        actor: 'Eleanor Vance'
      },
      {
        id: 'TL-07',
        date: '2025-02-14',
        title: 'Firmware Update & Preventive Maintenance',
        type: 'Maintenance',
        description: 'Updated Cisco IOS XE to version 17.9.4 and cleaned fan dust assembly.',
        actor: 'Sarah Jenkins'
      }
    ]
  },
  {
    id: 'AST-2026-004',
    tag: 'AP-99204',
    name: 'Lenovo ThinkPad P1 Gen 6 Workstation',
    category: 'Laptops & Desktops',
    brand: 'Lenovo',
    model: 'ThinkPad P1 Gen 6 (Core i9)',
    serialNumber: 'PF3910A92',
    departmentId: 'DEP-003',
    departmentName: 'Software Engineering',
    assignedEmployeeId: 'EMP-104',
    assignedEmployeeName: 'Michael Chang',
    location: 'Building A - Desk 305',
    status: 'Under Repair',
    condition: 'Needs Repair',
    purchaseDate: '2023-08-20',
    purchaseCost: 3200,
    currentValue: 1900,
    salvageValue: 400,
    expectedLifespanYears: 4,
    warrantyExpiry: '2026-08-20',
    warrantyVendor: 'Dell Commercial Solutions',
    warrantyStatus: 'Expiring Soon',
    qrCode: 'AP-99204-AST-2026-004-LENOVO-P1G6',
    specifications: {
      Processor: 'Intel Core i9-13900H (14 Cores)',
      GPU: 'NVIDIA RTX 4080 Ada 12GB',
      RAM: '32 GB DDR5',
      Storage: '1 TB PCIe Gen4 SSD'
    },
    notes: 'Thermal throttling issue and battery degradation reported.',
    timeline: [
      {
        id: 'TL-08',
        date: '2023-08-20',
        title: 'Purchased & Onboarded',
        type: 'Purchase',
        description: 'Assigned to Engineering department pool.',
        actor: 'Marcus Chen'
      },
      {
        id: 'TL-09',
        date: '2026-08-02',
        title: 'Repair Ticket Opened',
        type: 'Repair',
        description: 'Complaint TKT-801 raised for battery overheating. Sent to service vendor.',
        actor: 'Sarah Jenkins'
      }
    ]
  },
  {
    id: 'AST-2026-005',
    tag: 'AP-99205',
    name: 'iPad Pro 12.9" M2 (256GB Wi-Fi + Cellular)',
    category: 'Mobile & Tablets',
    brand: 'Apple',
    model: 'iPad Pro 6th Gen',
    serialNumber: 'DMPX892019A',
    departmentId: 'DEP-005',
    departmentName: 'Sales & Global Marketing',
    assignedEmployeeId: 'EMP-105',
    assignedEmployeeName: 'Jessica Taylor',
    location: 'Building B - Desk 312',
    status: 'In Use',
    condition: 'Good',
    purchaseDate: '2024-01-15',
    purchaseCost: 1299,
    currentValue: 980,
    salvageValue: 200,
    expectedLifespanYears: 3,
    warrantyExpiry: '2027-01-15',
    warrantyVendor: 'Apple Enterprise Direct',
    warrantyStatus: 'Active',
    qrCode: 'AP-99205-AST-2026-005-IPAD-PRO129',
    specifications: {
      Chip: 'Apple M2 Chip',
      Storage: '256 GB',
      Accessories: 'Includes Apple Pencil 2 & Magic Keyboard'
    },
    timeline: [
      {
        id: 'TL-10',
        date: '2024-01-15',
        title: 'Purchased for Executive Sales',
        type: 'Purchase',
        description: 'Assigned to Jessica Taylor for field demos and presentations.',
        actor: 'Marcus Chen'
      }
    ]
  },
  {
    id: 'AST-2026-006',
    tag: 'AP-99206',
    name: 'Herman Miller Aeron Ergonomic Chair (Size B)',
    category: 'Office Equipment',
    brand: 'Herman Miller',
    model: 'Aeron Fully Loaded Graphite',
    serialNumber: 'HM-AER-99120',
    departmentId: 'DEP-002',
    departmentName: 'Product Design & UX',
    assignedEmployeeId: 'EMP-101',
    assignedEmployeeName: 'Alex Rivera',
    location: 'Building B - Desk 204',
    status: 'In Use',
    condition: 'Good',
    purchaseDate: '2022-05-10',
    purchaseCost: 1450,
    currentValue: 1100,
    salvageValue: 300,
    expectedLifespanYears: 12,
    warrantyExpiry: '2034-05-10',
    warrantyVendor: 'Herman Miller Workspaces',
    warrantyStatus: 'Active',
    qrCode: 'AP-99206-AST-2026-006-HM-AERON',
    specifications: {
      Size: 'Size B (Medium)',
      Pellicle: 'Graphite 8Z Pellicle Mesh',
      Mechanisms: 'PostureFit SL, Tilt Limiter & Forward Tilt'
    },
    timeline: [
      {
        id: 'TL-11',
        date: '2022-05-10',
        title: 'Ergonomic Seating Setup',
        type: 'Purchase',
        description: 'Part of HQ Office Ergonomics Upgrade.',
        actor: 'Eleanor Vance'
      }
    ]
  },
  {
    id: 'AST-2026-007',
    tag: 'AP-99207',
    name: 'Dell Precision 7920 Tower Server / Workstation',
    category: 'Networking & Servers',
    brand: 'Dell',
    model: 'Precision 7920 Dual Xeon',
    serialNumber: 'DL-7920-99381',
    departmentId: 'DEP-001',
    departmentName: 'IT Operations & Security',
    assignedEmployeeId: undefined,
    assignedEmployeeName: undefined,
    location: 'Building A - Storage Pool 101',
    status: 'Available',
    condition: 'Fair',
    purchaseDate: '2021-02-10',
    purchaseCost: 8200,
    currentValue: 2100,
    salvageValue: 500,
    expectedLifespanYears: 5,
    warrantyExpiry: '2024-02-10',
    warrantyVendor: 'Dell Commercial Solutions',
    warrantyStatus: 'Expired',
    qrCode: 'AP-99207-AST-2026-007-DELL-P7920',
    specifications: {
      CPU: 'Dual Intel Xeon Gold 6248 (40 Cores total)',
      RAM: '128 GB ECC DDR4',
      GPU: 'NVIDIA Quadro RTX 6000 24GB'
    },
    notes: 'Decommissioned from main AI build farm. Cleaned and ready for secondary deployment.',
    timeline: [
      {
        id: 'TL-12',
        date: '2021-02-10',
        title: 'Purchased for AI R&D',
        type: 'Purchase',
        description: 'Primary AI model testing node.',
        actor: 'Eleanor Vance'
      },
      {
        id: 'TL-13',
        date: '2025-11-20',
        title: 'Returned to IT Storage Pool',
        type: 'Transfer',
        description: 'Replaced by cloud infrastructure nodes.',
        actor: 'Sarah Jenkins'
      }
    ]
  },
  {
    id: 'AST-2026-008',
    tag: 'AP-99208',
    name: 'HP LaserJet Enterprise MFP M528f Printer',
    category: 'Office Equipment',
    brand: 'HP',
    model: 'MFP M528f',
    serialNumber: 'CNHP9982104',
    departmentId: 'DEP-004',
    departmentName: 'Finance & Human Resources',
    assignedEmployeeId: 'EMP-106',
    assignedEmployeeName: 'Robert Sterling',
    location: 'Building A - Floor 1 Print Station',
    status: 'Disposed',
    condition: 'Decommissioned',
    purchaseDate: '2019-06-01',
    purchaseCost: 2100,
    currentValue: 0,
    salvageValue: 50,
    expectedLifespanYears: 5,
    warrantyExpiry: '2022-06-01',
    warrantyVendor: 'Dell Commercial Solutions',
    warrantyStatus: 'Expired',
    qrCode: 'AP-99208-AST-2026-008-HP-M528F',
    specifications: {
      Function: 'Print, Copy, Scan, Fax',
      Speed: 'Up to 45 ppm',
      Duplex: 'Automatic Two-Sided Printing'
    },
    timeline: [
      {
        id: 'TL-14',
        date: '2019-06-01',
        title: 'Purchased',
        type: 'Purchase',
        description: 'Standard HR floor printer.',
        actor: 'Eleanor Vance'
      },
      {
        id: 'TL-15',
        date: '2026-04-12',
        title: 'Recycled via E-Waste Program',
        type: 'Disposal',
        description: 'Fuser assembly unit failed beyond repair. Certificate CERT-2026-091 issued.',
        actor: 'Marcus Chen'
      }
    ]
  }
];

export const mockTransfers: AssignmentTransfer[] = [
  {
    id: 'TRF-1001',
    assetId: 'AST-2026-007',
    assetName: 'Dell Precision 7920 Tower Server',
    assetTag: 'AP-99207',
    type: 'Checkout',
    fromEmployee: 'IT Pool',
    toEmployee: 'Michael Chang',
    fromDept: 'IT Operations & Security',
    toDept: 'Software Engineering',
    fromLocation: 'Building A - Storage Pool 101',
    toLocation: 'Building A - Desk 305',
    requestedBy: 'Michael Chang',
    requestedDate: '2026-08-05',
    status: 'Pending Approval',
    reason: 'Requires local high-performance server node for offline microservice simulation testing.',
    notes: 'Approved by Dept Head Priya Sharma. Awaiting Asset Manager release.'
  },
  {
    id: 'TRF-1002',
    assetId: 'AST-2026-001',
    assetName: 'MacBook Pro 16" M3 Max',
    assetTag: 'AP-99201',
    type: 'Transfer',
    fromEmployee: 'David Kross',
    toEmployee: 'Alex Rivera',
    fromDept: 'Product Design & UX',
    toDept: 'Product Design & UX',
    fromLocation: 'Building B - Desk 201',
    toLocation: 'Building B - Desk 204',
    requestedBy: 'David Kross',
    requestedDate: '2024-03-18',
    status: 'Completed',
    reason: 'Reassigned workstation for new senior design lead onboarding.',
    notes: 'Physical check completed.'
  }
];

export const mockComplaints: ComplaintTicket[] = [
  {
    id: 'TKT-801',
    assetId: 'AST-2026-004',
    assetName: 'Lenovo ThinkPad P1 Gen 6 Workstation',
    assetTag: 'AP-99204',
    raisedBy: 'Michael Chang',
    raisedByEmail: 'michael.chang@assetpulse.io',
    department: 'Software Engineering',
    title: 'Extreme Thermal Throttling & Battery Expansion',
    description: 'Laptop chassis swells near trackpad under heavy compilation tasks. Fan produces grinding noise.',
    priority: 'Critical',
    status: 'In Progress',
    assignedTech: 'Sarah Jenkins',
    createdAt: '2026-08-02T10:15:00Z',
    resolutionNotes: 'Disassembled chassis, sent battery for immediate recall replacement. Thermals being repasted.'
  },
  {
    id: 'TKT-802',
    assetId: 'AST-2026-002',
    assetName: 'Dell UltraSharp 32" 4K USB-C Hub Monitor',
    assetTag: 'AP-99202',
    raisedBy: 'Alex Rivera',
    raisedByEmail: 'alex.rivera@assetpulse.io',
    department: 'Product Design & UX',
    title: 'USB-C Power Delivery Intermittent Drop',
    description: 'Monitor occasionally stops charging laptop and drops display signal during video calls.',
    priority: 'Medium',
    status: 'Open',
    createdAt: '2026-08-08T14:30:00Z'
  }
];

export const mockRepairs: RepairRecord[] = [
  {
    id: 'RPR-501',
    ticketId: 'TKT-801',
    assetId: 'AST-2026-004',
    assetName: 'Lenovo ThinkPad P1 Gen 6 Workstation',
    assetTag: 'AP-99204',
    vendorName: 'Dell Commercial Solutions / Lenovo Service Center',
    technicianName: 'Sarah Jenkins',
    issueDescription: 'Battery cell degradation, thermal paste burnout, chassis alignment.',
    repairCost: 650,
    downtimeDays: 5,
    status: 'In Repair',
    repairvsReplaceScore: 34, // Repair cost is 34% of residual value ($1,900)
    recommendation: 'Repair Recommended',
    startDate: '2026-08-03'
  }
];

export const mockPMs: PreventiveMaintenance[] = [
  {
    id: 'PM-201',
    title: 'Quarterly Server Room Rack & Power Audits',
    category: 'Networking & Servers',
    frequency: 'Quarterly',
    nextDueDate: '2026-09-01',
    lastPerformedDate: '2026-06-01',
    assignedTech: 'Sarah Jenkins',
    active: true,
    checklist: [
      { id: 'chk-1', task: 'Inspect UPS backup batteries & test failure cutover', completed: true },
      { id: 'chk-2', task: 'Clean dust filters on Cisco Catalyst switches and racks', completed: true },
      { id: 'chk-3', task: 'Verify temperature sensors and HVAC threshold logs', completed: false },
      { id: 'chk-4', task: 'Re-label loose patch cables and organize cable trays', completed: false }
    ]
  },
  {
    id: 'PM-202',
    title: 'Bi-Annual Laptop Battery & Thermal Health Routine',
    category: 'Laptops & Desktops',
    frequency: 'Bi-Annually',
    nextDueDate: '2026-08-15',
    lastPerformedDate: '2026-02-15',
    assignedTech: 'Sarah Jenkins',
    active: true,
    checklist: [
      { id: 'chk-5', task: 'Run diagnostic health check on all MacBooks & ThinkPads', completed: false },
      { id: 'chk-6', task: 'Verify FileVault / BitLocker encryption status on devices', completed: true },
      { id: 'chk-7', task: 'Check battery cycle counts above 800 cycles', completed: false }
    ]
  }
];

export const mockWarranties: WarrantyRecord[] = [
  {
    id: 'WRN-301',
    assetId: 'AST-2026-001',
    assetName: 'MacBook Pro 16" M3 Max',
    vendorName: 'Apple Enterprise Direct',
    policyNumber: 'APP-ENT-2024-998',
    startDate: '2024-03-15',
    expiryDate: '2027-03-15',
    coverageDetails: 'AppleCare+ for Enterprise: 24/7 Priority Tech Support, $0 accidental damage deductible (up to 2 per year), express replacement.',
    claimCount: 0,
    status: 'Active'
  },
  {
    id: 'WRN-302',
    assetId: 'AST-2026-002',
    assetName: 'Dell UltraSharp 32" 4K USB-C Hub Monitor',
    vendorName: 'Dell Commercial Solutions',
    policyNumber: 'DELL-PRO-8812',
    startDate: '2024-04-01',
    expiryDate: '2026-09-10',
    coverageDetails: '3-Year Premium Panel Exchange & Advanced Exchange Service.',
    claimCount: 1,
    status: 'Expiring Soon'
  },
  {
    id: 'WRN-303',
    assetId: 'AST-2026-003',
    assetName: 'Cisco Catalyst 9300 48-Port PoE+ Switch',
    vendorName: 'Cisco Systems Global',
    policyNumber: 'CSCO-TAC-9921',
    startDate: '2023-01-10',
    expiryDate: '2028-01-10',
    coverageDetails: 'SMARTnet 24x7x4 Onsite Hardware & TAC Support.',
    claimCount: 0,
    status: 'Active'
  },
  {
    id: 'WRN-304',
    assetId: 'AST-2026-004',
    assetName: 'Lenovo ThinkPad P1 Gen 6 Workstation',
    vendorName: 'Dell Commercial Solutions',
    policyNumber: 'LNV-P1-9920',
    startDate: '2023-08-20',
    expiryDate: '2026-08-20',
    coverageDetails: 'Onsite Premier Support with Next Business Day Response & Sealed Battery Warranty.',
    claimCount: 1,
    status: 'Expiring Soon'
  },
  {
    id: 'WRN-305',
    assetId: 'AST-2026-005',
    assetName: 'iPad Pro 12.9" M2',
    vendorName: 'Apple Enterprise Direct',
    policyNumber: 'APP-PAD-2024-01',
    startDate: '2024-01-15',
    expiryDate: '2027-01-15',
    coverageDetails: 'AppleCare+ for Business with Theft & Loss Protection.',
    claimCount: 0,
    status: 'Active'
  },
  {
    id: 'WRN-306',
    assetId: 'AST-2026-007',
    assetName: 'Dell Precision 7920 Tower Server',
    vendorName: 'Dell Commercial Solutions',
    policyNumber: 'DELL-SVR-3019',
    startDate: '2021-02-10',
    expiryDate: '2024-02-10',
    coverageDetails: 'ProSupport Plus 24x7 Mission Critical Hardware Support.',
    claimCount: 2,
    status: 'Expired'
  },
  {
    id: 'WRN-307',
    assetId: 'AST-2026-008',
    assetName: 'HP LaserJet Enterprise MFP M528f Printer',
    vendorName: 'Dell Commercial Solutions',
    policyNumber: 'HP-ENT-8820',
    startDate: '2019-06-01',
    expiryDate: '2022-06-01',
    coverageDetails: 'HP Care Pack Onsite Maintenance Service.',
    claimCount: 3,
    status: 'Expired'
  }
];

export const mockAudits: AssetAudit[] = [
  {
    id: 'AUD-2026-Q3',
    campaignName: 'Q3 2026 HQ Physical Inventory & Location Audit',
    targetDepartment: 'All Departments',
    targetLocation: 'Headquarters - Building A',
    auditorName: 'Alex Mercer (Lead Auditor)',
    startDate: '2026-08-01',
    endDate: '2026-08-31',
    status: 'In Progress',
    totalExpected: 6,
    totalScanned: 5,
    notes: 'Quarterly hardware audit for compliance and insurance verification.',
    items: [
      {
        assetId: 'AST-2026-001',
        assetName: 'Apple MacBook Pro 16" M3 Max',
        assetTag: 'AP-10291',
        category: 'Laptops & Desktops',
        expectedLocation: 'Building A - Floor 3 (Desk 301)',
        assignedEmployeeName: 'Alex Mercer',
        status: 'Found',
        notes: 'Serial & asset label intact. Excellent condition.',
        verifiedAt: '2026-08-02 10:15',
        verifiedBy: 'Alex Mercer'
      },
      {
        assetId: 'AST-2026-002',
        assetName: 'Dell UltraSharp U2723QE 27" 4K Monitor',
        assetTag: 'AP-88301',
        category: 'Monitors & Displays',
        expectedLocation: 'Building A - Floor 3 (Desk 301)',
        assignedEmployeeName: 'Alex Mercer',
        status: 'Found',
        notes: 'Verified in position on desk arm.',
        verifiedAt: '2026-08-02 10:18',
        verifiedBy: 'Alex Mercer'
      },
      {
        assetId: 'AST-2026-003',
        assetName: 'Cisco Catalyst 9300 48-Port PoE+ Switch',
        assetTag: 'AP-90012',
        category: 'Networking & Servers',
        expectedLocation: 'Server Room 102 - Rack B',
        assignedEmployeeName: 'Unassigned',
        status: 'Found',
        notes: 'Mounted in Rack B, port lights active.',
        verifiedAt: '2026-08-03 14:00',
        verifiedBy: 'Alex Mercer'
      },
      {
        assetId: 'AST-2026-004',
        assetName: 'Lenovo ThinkPad P1 Gen 6 Workstation',
        assetTag: 'AP-44021',
        category: 'Laptops & Desktops',
        expectedLocation: 'Building B - Floor 2',
        assignedEmployeeName: 'Samantha Reed',
        status: 'Missing',
        notes: 'Not found at assigned desk. Employee on remote assignment, pending confirmation.',
        verifiedAt: '2026-08-05 11:30',
        verifiedBy: 'Alex Mercer'
      },
      {
        assetId: 'AST-2026-005',
        assetName: 'iPad Pro 12.9" M2 (128GB Wi-Fi)',
        assetTag: 'AP-33210',
        category: 'Mobile & Tablets',
        expectedLocation: 'Design Studio 201',
        assignedEmployeeName: 'Marcus Vance',
        status: 'Damaged',
        notes: 'Small hairline crack on screen bezel; touchscreen functional.',
        verifiedAt: '2026-08-06 16:45',
        verifiedBy: 'Alex Mercer'
      },
      {
        assetId: 'AST-2026-006',
        assetName: 'Sony WH-1000XM5 Wireless Headphones',
        assetTag: 'AP-11002',
        category: 'Peripherals',
        expectedLocation: 'Building A - Desk 305',
        assignedEmployeeName: 'David Chen',
        status: 'Pending',
        notes: ''
      }
    ]
  }
];

export const mockDisposals: DisposalRecord[] = [
  {
    id: 'DSP-2026-01',
    assetId: 'AST-2026-008',
    assetName: 'HP LaserJet Enterprise MFP M528f Printer',
    assetTag: 'AP-99208',
    reason: 'Beyond Economical Repair',
    disposalDate: '2026-04-12',
    condition: 'Decommissioned',
    requestedBy: 'Sarah Jenkins',
    approvedBy: 'Eleanor Vance',
    approvalStatus: 'Disposed',
    status: 'Disposed',
    residualValue: 0,
    saleOrRecycleAmount: 50,
    certificateNo: 'CERT-EWASTE-2026-091',
    notes: 'Internal fuser unit failure; cost of repair exceeds replacement value. Recycled via certified GreenTech E-Waste.'
  }
];

export const mockActivityLogs: ActivityLog[] = [
  {
    id: 'LOG-001',
    userId: 'USR-001',
    userName: 'Alexander Wright',
    action: 'REGISTER',
    entityType: 'USER',
    entityId: 'USR-001',
    details: 'Registered Super Admin account alexander.wright@assetpulse.com.',
    createdAt: '2026-08-10T07:00:00.000Z'
  },
  {
    id: 'LOG-002',
    userId: 'USR-001',
    userName: 'Alexander Wright',
    action: 'LOGIN',
    entityType: 'AUTH',
    entityId: 'USR-001',
    details: 'User authenticated successfully.',
    createdAt: '2026-08-10T07:05:00.000Z'
  },
  {
    id: 'LOG-003',
    userId: 'USR-001',
    userName: 'Alexander Wright',
    action: 'ROLE_CHANGED',
    entityType: 'USER',
    entityId: 'USR-003',
    details: 'Updated role for David Miller from Employee to Technician.',
    createdAt: '2026-08-10T07:20:00.000Z'
  }
];

export const mockSystemStats: SystemStats = {
  totalAssets: 231,
  assignedAssets: 182,
  availableAssets: 34,
  underRepair: 7,
  warrantyExpiring: 12,
  disposedAssets: 8,
  totalValuation: 845200,
  openComplaints: 3,
  pendingTransfers: 2,
  upcomingMaintenances: 4
};
