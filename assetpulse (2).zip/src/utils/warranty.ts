export type WarrantyStatus = 'Active' | 'Expiring Soon' | 'Expired';

/**
 * Automatically calculates warranty status based on expiry date relative to today's date.
 * Default threshold for 'Expiring Soon' is within 45 days.
 */
export function calculateWarrantyStatus(
  expiryDateStr?: string,
  thresholdDays: number = 45
): WarrantyStatus {
  if (!expiryDateStr) return 'Expired';

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const expiry = new Date(expiryDateStr);
  expiry.setHours(0, 0, 0, 0);

  if (isNaN(expiry.getTime())) return 'Expired';

  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return 'Expired';
  } else if (diffDays <= thresholdDays) {
    return 'Expiring Soon';
  } else {
    return 'Active';
  }
}

/**
 * Returns exact number of days remaining until expiry (negative if already expired).
 */
export function getDaysRemaining(expiryDateStr?: string): number {
  if (!expiryDateStr) return -999;

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const expiry = new Date(expiryDateStr);
  expiry.setHours(0, 0, 0, 0);

  if (isNaN(expiry.getTime())) return -999;

  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Format days remaining as human readable text with appropriate badge color
 */
export function formatDaysRemainingText(expiryDateStr?: string): {
  text: string;
  badgeColor: 'emerald' | 'amber' | 'rose';
  days: number;
} {
  const days = getDaysRemaining(expiryDateStr);

  if (days < -900) {
    return {
      text: 'No Expiry Date Set',
      badgeColor: 'rose',
      days: -999
    };
  } else if (days < 0) {
    const past = Math.abs(days);
    return {
      text: `Expired ${past} ${past === 1 ? 'day' : 'days'} ago`,
      badgeColor: 'rose',
      days
    };
  } else if (days === 0) {
    return {
      text: 'Expires Today!',
      badgeColor: 'amber',
      days: 0
    };
  } else if (days <= 45) {
    return {
      text: `Expires in ${days} ${days === 1 ? 'day' : 'days'}`,
      badgeColor: 'amber',
      days
    };
  } else {
    return {
      text: `Valid (${days} days remaining)`,
      badgeColor: 'emerald',
      days
    };
  }
}
