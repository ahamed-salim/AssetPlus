import { inMemoryDb } from '../config/db';
import { AssignmentTransfer } from '../../src/types';

export const assignmentService = {
  async getAll() {
    return inMemoryDb.transfers;
  },

  async getById(id: string) {
    return inMemoryDb.transfers.find(t => t.id === id);
  },

  async create(data: Omit<AssignmentTransfer, 'id'>) {
    const id = `TRF-${String(inMemoryDb.transfers.length + 1).padStart(3, '0')}`;
    const newTransfer: AssignmentTransfer = { id, ...data };
    inMemoryDb.transfers.push(newTransfer);
    return newTransfer;
  },

  async update(id: string, data: Partial<AssignmentTransfer>) {
    const index = inMemoryDb.transfers.findIndex(t => t.id === id);
    if (index === -1) return null;
    inMemoryDb.transfers[index] = { ...inMemoryDb.transfers[index], ...data };
    return inMemoryDb.transfers[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.transfers.findIndex(t => t.id === id);
    if (index === -1) return false;
    inMemoryDb.transfers.splice(index, 1);
    return true;
  }
};
