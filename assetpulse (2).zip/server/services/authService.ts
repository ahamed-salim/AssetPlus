import bcrypt from 'bcryptjs';
import { userService, sanitizeUser } from './userService';
import { generateToken } from '../middleware/auth';
import { Role } from '../../src/types';

export const authService = {
  async login(email: string, password?: string) {
    if (!email || !password) {
      throw new Error('Email address and password are required.');
    }

    const userWithPass = await userService.findByEmailWithPassword(email);

    if (!userWithPass) {
      throw new Error('Invalid email address or password.');
    }

    if (userWithPass.status === 'Inactive' || userWithPass.status === 'Disabled') {
      throw new Error('This account has been disabled. Please contact your system administrator.');
    }

    // Verify password with bcrypt
    if (!userWithPass.password_hash) {
      throw new Error('Invalid email address or password.');
    }

    const isPasswordValid = await bcrypt.compare(password, userWithPass.password_hash);
    if (!isPasswordValid) {
      throw new Error('Invalid email address or password.');
    }

    const cleanUser = sanitizeUser(userWithPass);
    const token = generateToken({
      id: cleanUser.id,
      name: cleanUser.name,
      email: cleanUser.email,
      role: cleanUser.role,
      departmentId: cleanUser.departmentId,
      departmentName: cleanUser.departmentName
    });

    return {
      user: cleanUser,
      token,
      expiresIn: '7d'
    };
  },

  async register(data: {
    name: string;
    email: string;
    password: string;
    role?: Role;
    departmentId?: string;
    departmentName?: string;
    title?: string;
  }) {
    if (!data.name || !data.email || !data.password) {
      throw new Error('Name, email, and password are required.');
    }

    if (data.password.length < 6) {
      throw new Error('Password must be at least 6 characters in length.');
    }

    const existing = await userService.findByEmailWithPassword(data.email);
    if (existing) {
      throw new Error('An account with this email address already exists.');
    }

    const password_hash = await bcrypt.hash(data.password, 10);

    const newUser = await userService.create({
      name: data.name.trim(),
      email: data.email.trim().toLowerCase(),
      password_hash,
      role: data.role || 'employee',
      status: 'Active',
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
      departmentId: data.departmentId || 'DEP-001',
      departmentName: data.departmentName || 'General Staff',
      title: data.title || 'Employee',
      phone: '+1 (555) 000-0000'
    });

    const cleanUser = sanitizeUser(newUser);
    const token = generateToken({
      id: cleanUser.id,
      name: cleanUser.name,
      email: cleanUser.email,
      role: cleanUser.role,
      departmentId: cleanUser.departmentId,
      departmentName: cleanUser.departmentName
    });

    return {
      user: cleanUser,
      token,
      expiresIn: '7d'
    };
  },

  async getCurrentUser(id: string) {
    const user = await userService.getById(id);
    if (!user) {
      throw new Error('Authenticated user record not found.');
    }
    return user;
  },

  async forgotPassword(email: string) {
    await userService.findByEmailWithPassword(email);
    return {
      message: 'If an account exists for this email address, password reset instructions have been sent.'
    };
  }
};
