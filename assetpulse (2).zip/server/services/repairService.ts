import { inMemoryDb } from '../config/db';
import { RepairRecord } from '../../src/types';

export const repairService = {
  async getAll() {
    return inMemoryDb.repairs;
  },

  async getById(id: string) {
    return inMemoryDb.repairs.find(r => r.id === id);
  },

  async create(data: Omit<RepairRecord, 'id'>) {
    const id = `REP-${String(inMemoryDb.repairs.length + 1).padStart(3, '0')}`;
    const newRecord: RepairRecord = { id, ...data };
    inMemoryDb.repairs.push(newRecord);
    return newRecord;
  },

  async update(id: string, data: Partial<RepairRecord>) {
    const index = inMemoryDb.repairs.findIndex(r => r.id === id);
    if (index === -1) return null;
    inMemoryDb.repairs[index] = { ...inMemoryDb.repairs[index], ...data };
    return inMemoryDb.repairs[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.repairs.findIndex(r => r.id === id);
    if (index === -1) return false;
    inMemoryDb.repairs.splice(index, 1);
    return true;
  }
};
