import { inMemoryDb } from '../config/db';
import { DisposalRecord } from '../../src/types';

export const disposalService = {
  async getAll() {
    return inMemoryDb.disposals;
  },

  async getById(id: string) {
    return inMemoryDb.disposals.find(d => d.id === id);
  },

  async create(data: Omit<DisposalRecord, 'id'>) {
    const id = `DSP-${String(inMemoryDb.disposals.length + 1).padStart(3, '0')}`;
    const newRecord: DisposalRecord = { id, ...data };
    inMemoryDb.disposals.push(newRecord);
    return newRecord;
  },

  async update(id: string, data: Partial<DisposalRecord>) {
    const index = inMemoryDb.disposals.findIndex(d => d.id === id);
    if (index === -1) return null;
    inMemoryDb.disposals[index] = { ...inMemoryDb.disposals[index], ...data };
    return inMemoryDb.disposals[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.disposals.findIndex(d => d.id === id);
    if (index === -1) return false;
    inMemoryDb.disposals.splice(index, 1);
    return true;
  }
};
