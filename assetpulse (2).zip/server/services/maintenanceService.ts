import { inMemoryDb } from '../config/db';
import { PreventiveMaintenance } from '../../src/types';

export const maintenanceService = {
  async getAll() {
    return inMemoryDb.maintenance;
  },

  async getById(id: string) {
    return inMemoryDb.maintenance.find(m => m.id === id);
  },

  async create(data: Omit<PreventiveMaintenance, 'id'>) {
    const id = `PM-${String(inMemoryDb.maintenance.length + 1).padStart(3, '0')}`;
    const newPM: PreventiveMaintenance = { id, ...data };
    inMemoryDb.maintenance.push(newPM);
    return newPM;
  },

  async update(id: string, data: Partial<PreventiveMaintenance>) {
    const index = inMemoryDb.maintenance.findIndex(m => m.id === id);
    if (index === -1) return null;
    inMemoryDb.maintenance[index] = { ...inMemoryDb.maintenance[index], ...data };
    return inMemoryDb.maintenance[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.maintenance.findIndex(m => m.id === id);
    if (index === -1) return false;
    inMemoryDb.maintenance.splice(index, 1);
    return true;
  }
};
