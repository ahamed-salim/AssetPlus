import { inMemoryDb } from '../config/db';
import { ComplaintTicket } from '../../src/types';

export const complaintService = {
  async getAll() {
    return inMemoryDb.complaints;
  },

  async getById(id: string) {
    return inMemoryDb.complaints.find(c => c.id === id);
  },

  async create(data: Omit<ComplaintTicket, 'id' | 'createdAt'>) {
    const id = `TKT-${String(inMemoryDb.complaints.length + 1).padStart(3, '0')}`;
    const newTicket: ComplaintTicket = {
      id,
      ...data,
      createdAt: new Date().toISOString().split('T')[0]
    };
    inMemoryDb.complaints.push(newTicket);
    return newTicket;
  },

  async update(id: string, data: Partial<ComplaintTicket>) {
    const index = inMemoryDb.complaints.findIndex(c => c.id === id);
    if (index === -1) return null;
    inMemoryDb.complaints[index] = { ...inMemoryDb.complaints[index], ...data };
    return inMemoryDb.complaints[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.complaints.findIndex(c => c.id === id);
    if (index === -1) return false;
    inMemoryDb.complaints.splice(index, 1);
    return true;
  }
};
