import { inMemoryDb } from '../config/db';
import { Employee } from '../../src/types';

export const employeeService = {
  async getAll() {
    return inMemoryDb.employees;
  },

  async getById(id: string) {
    return inMemoryDb.employees.find(e => e.id === id);
  },

  async create(data: Omit<Employee, 'id'>) {
    const newId = `EMP-${String(inMemoryDb.employees.length + 1).padStart(3, '0')}`;
    const newEmp: Employee = { id: newId, ...data };
    inMemoryDb.employees.push(newEmp);
    return newEmp;
  },

  async update(id: string, data: Partial<Employee>) {
    const index = inMemoryDb.employees.findIndex(e => e.id === id);
    if (index === -1) return null;
    inMemoryDb.employees[index] = { ...inMemoryDb.employees[index], ...data };
    return inMemoryDb.employees[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.employees.findIndex(e => e.id === id);
    if (index === -1) return false;
    inMemoryDb.employees.splice(index, 1);
    return true;
  }
};
