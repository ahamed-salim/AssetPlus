import { inMemoryDb } from '../config/db';
import { AssetAudit } from '../../src/types';

export const auditService = {
  async getAll() {
    return inMemoryDb.audits;
  },

  async getById(id: string) {
    return inMemoryDb.audits.find(a => a.id === id);
  },

  async create(data: Omit<AssetAudit, 'id'>) {
    const id = `AUD-${String(inMemoryDb.audits.length + 1).padStart(3, '0')}`;
    const newAudit: AssetAudit = { id, ...data };
    inMemoryDb.audits.push(newAudit);
    return newAudit;
  },

  async update(id: string, data: Partial<AssetAudit>) {
    const index = inMemoryDb.audits.findIndex(a => a.id === id);
    if (index === -1) return null;
    inMemoryDb.audits[index] = { ...inMemoryDb.audits[index], ...data };
    return inMemoryDb.audits[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.audits.findIndex(a => a.id === id);
    if (index === -1) return false;
    inMemoryDb.audits.splice(index, 1);
    return true;
  }
};
