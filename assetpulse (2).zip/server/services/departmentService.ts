import { inMemoryDb } from '../config/db';
import { Department } from '../../src/types';

export const departmentService = {
  async getAll() {
    return inMemoryDb.departments;
  },

  async getById(id: string) {
    return inMemoryDb.departments.find(d => d.id === id);
  },

  async create(data: Omit<Department, 'id'>) {
    const newId = `DEP-${String(inMemoryDb.departments.length + 1).padStart(3, '0')}`;
    const newDept: Department = { id: newId, ...data };
    inMemoryDb.departments.push(newDept);
    return newDept;
  },

  async update(id: string, data: Partial<Department>) {
    const index = inMemoryDb.departments.findIndex(d => d.id === id);
    if (index === -1) return null;
    inMemoryDb.departments[index] = { ...inMemoryDb.departments[index], ...data };
    return inMemoryDb.departments[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.departments.findIndex(d => d.id === id);
    if (index === -1) return false;
    inMemoryDb.departments.splice(index, 1);
    return true;
  }
};
