import { inMemoryDb, isMySQLConnected, query } from '../config/db';
import { ActivityLog } from '../../src/types';

export const activityLogService = {
  async getAll(): Promise<ActivityLog[]> {
    if (isMySQLConnected()) {
      try {
        const rows = await query<any>(
          'SELECT id, user_id as userId, user_name as userName, action, entity_type as entityType, entity_id as entityId, details, ip_address as ipAddress, created_at as createdAt FROM activity_logs ORDER BY created_at DESC'
        );
        if (rows && rows.length > 0) return rows;
      } catch (err) {
        console.warn('MySQL fetch activity_logs failed:', err);
      }
    }
    const logs = inMemoryDb.activityLogs || [];
    return [...logs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async log(entry: {
    userId?: string;
    userName?: string;
    action: string;
    entityType: string;
    entityId: string;
    details?: string;
    ipAddress?: string;
  }): Promise<ActivityLog> {
    const newLog: ActivityLog = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: entry.userId || 'SYSTEM',
      userName: entry.userName || 'System Visitor',
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      details: entry.details || '',
      ipAddress: entry.ipAddress || '127.0.0.1',
      createdAt: new Date().toISOString()
    };

    if (!inMemoryDb.activityLogs) {
      inMemoryDb.activityLogs = [];
    }
    inMemoryDb.activityLogs.unshift(newLog);

    if (isMySQLConnected()) {
      try {
        await query(
          'INSERT INTO activity_logs (id, user_id, user_name, action, entity_type, entity_id, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [
            newLog.id,
            newLog.userId,
            newLog.userName,
            newLog.action,
            newLog.entityType,
            newLog.entityId,
            newLog.details,
            newLog.ipAddress,
            newLog.createdAt
          ]
        );
      } catch (err) {
        console.warn('MySQL insert activity_log failed:', err);
      }
    }

    return newLog;
  }
};
