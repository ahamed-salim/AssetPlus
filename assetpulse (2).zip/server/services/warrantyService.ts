import { inMemoryDb } from '../config/db';
import { WarrantyRecord } from '../../src/types';

export const warrantyService = {
  async getAll() {
    return inMemoryDb.warranties;
  },

  async getById(id: string) {
    return inMemoryDb.warranties.find(w => w.id === id);
  },

  async create(data: Omit<WarrantyRecord, 'id'>) {
    const id = `WRN-${String(inMemoryDb.warranties.length + 1).padStart(3, '0')}`;
    const newRecord: WarrantyRecord = { id, ...data };
    inMemoryDb.warranties.push(newRecord);
    return newRecord;
  },

  async update(id: string, data: Partial<WarrantyRecord>) {
    const index = inMemoryDb.warranties.findIndex(w => w.id === id);
    if (index === -1) return null;
    inMemoryDb.warranties[index] = { ...inMemoryDb.warranties[index], ...data };
    return inMemoryDb.warranties[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.warranties.findIndex(w => w.id === id);
    if (index === -1) return false;
    inMemoryDb.warranties.splice(index, 1);
    return true;
  }
};
