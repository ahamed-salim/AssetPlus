import { inMemoryDb } from '../config/db';
import { Asset, LifecycleEvent } from '../../src/types';

export const assetService = {
  async getAll() {
    return inMemoryDb.assets;
  },

  async getById(id: string) {
    return inMemoryDb.assets.find(a => a.id === id || a.tag === id);
  },

  async create(data: Omit<Asset, 'id' | 'qrCode' | 'timeline'>) {
    const id = `AST-2026-${String(inMemoryDb.assets.length + 1).padStart(3, '0')}`;
    const qrCode = `AP-${data.tag}-${id}`;
    const initialEvent: LifecycleEvent = {
      id: `EVT-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      title: 'Asset Onboarded',
      type: 'Purchase',
      description: `Registered asset into enterprise inventory under ${data.departmentName}.`,
      actor: 'System Admin',
      badgeColor: 'emerald'
    };

    const newAsset: Asset = {
      ...data,
      id,
      qrCode,
      timeline: [initialEvent]
    };

    inMemoryDb.assets.push(newAsset);
    return newAsset;
  },

  async update(id: string, data: Partial<Asset>) {
    const index = inMemoryDb.assets.findIndex(a => a.id === id || a.tag === id);
    if (index === -1) return null;
    inMemoryDb.assets[index] = { ...inMemoryDb.assets[index], ...data };
    return inMemoryDb.assets[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.assets.findIndex(a => a.id === id || a.tag === id);
    if (index === -1) return false;
    inMemoryDb.assets.splice(index, 1);
    return true;
  }
};
