import { inMemoryDb } from '../config/db';
import { Vendor } from '../../src/types';

export const vendorService = {
  async getAll() {
    return inMemoryDb.vendors;
  },

  async getById(id: string) {
    return inMemoryDb.vendors.find(v => v.id === id);
  },

  async create(data: Omit<Vendor, 'id'>) {
    const newId = `VND-${String(inMemoryDb.vendors.length + 1).padStart(3, '0')}`;
    const newVendor: Vendor = { id: newId, ...data };
    inMemoryDb.vendors.push(newVendor);
    return newVendor;
  },

  async update(id: string, data: Partial<Vendor>) {
    const index = inMemoryDb.vendors.findIndex(v => v.id === id);
    if (index === -1) return null;
    inMemoryDb.vendors[index] = { ...inMemoryDb.vendors[index], ...data };
    return inMemoryDb.vendors[index];
  },

  async delete(id: string) {
    const index = inMemoryDb.vendors.findIndex(v => v.id === id);
    if (index === -1) return false;
    inMemoryDb.vendors.splice(index, 1);
    return true;
  }
};
