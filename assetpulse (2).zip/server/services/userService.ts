import { inMemoryDb, isMySQLConnected, query } from '../config/db';
import { User } from '../../src/types';

export function sanitizeUser(user: any): User {
  if (!user) return user;
  const { password_hash, password, ...cleanUser } = user;
  return cleanUser as User;
}

export const userService = {
  async getAll() {
    if (isMySQLConnected()) {
      try {
        const rows = await query<User>('SELECT id, name, email, role, avatar, departmentId, departmentName, title, phone, status FROM users');
        if (rows && rows.length > 0) return rows.map(sanitizeUser);
      } catch (err) {
        console.warn('MySQL fetch users failed:', err);
      }
    }
    return inMemoryDb.users.map(sanitizeUser);
  },

  async getById(id: string) {
    if (isMySQLConnected()) {
      try {
        const rows = await query<User>('SELECT id, name, email, role, avatar, departmentId, departmentName, title, phone, status FROM users WHERE id = ?', [id]);
        if (rows && rows.length > 0) return sanitizeUser(rows[0]);
      } catch (err) {
        console.warn('MySQL getById user failed:', err);
      }
    }
    const user = inMemoryDb.users.find(u => u.id === id);
    return user ? sanitizeUser(user) : undefined;
  },

  async findByEmailWithPassword(email: string) {
    const cleanEmail = email.trim().toLowerCase();
    if (isMySQLConnected()) {
      try {
        const rows = await query<any>('SELECT * FROM users WHERE LOWER(email) = ?', [cleanEmail]);
        if (rows && rows.length > 0) return rows[0];
      } catch (err) {
        console.warn('MySQL findByEmail failed:', err);
      }
    }
    return inMemoryDb.users.find(u => u.email.toLowerCase() === cleanEmail);
  },

  async create(data: any) {
    const newId = `USR-${String(inMemoryDb.users.length + 1).padStart(3, '0')}`;
    const newUser: any = { 
      id: newId, 
      status: data.status || 'Active',
      avatar: data.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      departmentId: data.departmentId || 'DEP-001',
      departmentName: data.departmentName || 'IT Operations & Security',
      title: data.title || 'Staff Member',
      phone: data.phone || '+1 (555) 000-0000',
      ...data 
    };

    inMemoryDb.users.push(newUser);

    if (isMySQLConnected()) {
      try {
        await query(
          'INSERT INTO users (id, name, email, password_hash, role, avatar, departmentId, departmentName, title, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [
            newUser.id, 
            newUser.name, 
            newUser.email, 
            newUser.password_hash || '', 
            newUser.role, 
            newUser.avatar, 
            newUser.departmentId, 
            newUser.departmentName, 
            newUser.title, 
            newUser.phone, 
            newUser.status
          ]
        );
      } catch (err) {
        console.warn('MySQL user insert failed:', err);
      }
    }

    return sanitizeUser(newUser);
  },

  async update(id: string, data: Partial<User>) {
    const index = inMemoryDb.users.findIndex(u => u.id === id);
    if (index === -1) return null;

    const updatedUser = { ...inMemoryDb.users[index], ...data };
    inMemoryDb.users[index] = updatedUser;

    if (isMySQLConnected()) {
      try {
        const keys = Object.keys(data).filter(k => k !== 'id' && k !== 'password_hash');
        if (keys.length > 0) {
          const fields = keys.map(key => `${key} = ?`).join(', ');
          const values = keys.map(key => (data as any)[key]);
          await query(`UPDATE users SET ${fields} WHERE id = ?`, [...values, id]);
        }
      } catch (err) {
        console.warn('MySQL user update failed:', err);
      }
    }

    return sanitizeUser(updatedUser);
  },

  async delete(id: string) {
    const index = inMemoryDb.users.findIndex(u => u.id === id);
    if (index === -1) return false;

    inMemoryDb.users.splice(index, 1);

    if (isMySQLConnected()) {
      try {
        await query('DELETE FROM users WHERE id = ?', [id]);
      } catch (err) {
        console.warn('MySQL user delete failed:', err);
      }
    }

    return true;
  },

  async getActiveSuperAdminCount(): Promise<number> {
    const allUsers = await this.getAll();
    return allUsers.filter(u => u.role === 'super_admin' && u.status !== 'Inactive').length;
  }
};
