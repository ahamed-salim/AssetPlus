import { Request, Response, NextFunction } from 'express';
import { disposalService } from '../services/disposalService';
import { activityLogService } from '../services/activityLogService';

export const disposalController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const records = await disposalService.getAll();
      res.json(records);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const record = await disposalService.getById(req.params.id);
      if (!record) return res.status(404).json({ error: 'Disposal record not found.' });
      res.json(record);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const created = await disposalService.create(req.body);

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'ASSET_DISPOSED',
        entityType: 'DISPOSAL',
        entityId: created.id,
        details: `Recorded disposal for asset ${created.assetTag || created.assetName || ''} (${created.reason}).`,
        ipAddress: req.ip
      });

      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await disposalService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Disposal record not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await disposalService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Disposal record not found.' });
      res.json({ message: 'Disposal record deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
