import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/authService';
import { activityLogService } from '../services/activityLogService';

export const authController = {
  async login(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Email address and password are required.'
        });
      }
      const result = await authService.login(email, password);

      await activityLogService.log({
        userId: result.user.id,
        userName: result.user.name,
        action: 'LOGIN',
        entityType: 'AUTH',
        entityId: result.user.id,
        details: `User ${result.user.email} authenticated successfully.`,
        ipAddress: req.ip
      });

      return res.json({
        success: true,
        user: result.user,
        token: result.token
      });
    } catch (err: any) {
      await activityLogService.log({
        userId: 'ANONYMOUS',
        userName: req.body?.email || 'Unknown Visitor',
        action: 'FAILED_LOGIN',
        entityType: 'AUTH',
        entityId: req.body?.email || 'UNKNOWN',
        details: `Failed login attempt for email: ${req.body?.email || 'N/A'}.`,
        ipAddress: req.ip
      });
      return res.status(401).json({
        success: false,
        message: err.message || 'Invalid email or password'
      });
    }
  },

  async register(req: Request, res: Response, next: NextFunction) {
    try {
      const { name, email, password, confirmPassword } = req.body;
      
      if (!name || !email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Name, email address, and password are required.'
        });
      }

      if (confirmPassword !== undefined && password !== confirmPassword) {
        return res.status(400).json({
          success: false,
          message: 'Passwords do not match.'
        });
      }

      // Security requirement: Public registrations ALWAYS create an Employee role with Active status.
      const assignedRole = 'employee';

      const result = await authService.register({
        name,
        email,
        password,
        role: assignedRole
      });

      await activityLogService.log({
        userId: result.user.id,
        userName: result.user.name,
        action: 'REGISTER',
        entityType: 'USER',
        entityId: result.user.id,
        details: `Registered new account ${result.user.email} with Employee role.`,
        ipAddress: req.ip
      });

      return res.status(201).json({
        success: true,
        user: result.user,
        token: result.token
      });
    } catch (err: any) {
      return res.status(400).json({
        success: false,
        message: err.message || 'Registration failed.'
      });
    }
  },

  async me(req: Request, res: Response, next: NextFunction) {
    try {
      if (!req.user || !req.user.id) {
        return res.status(401).json({
          success: false,
          message: 'Unauthorized. Token required.'
        });
      }
      const user = await authService.getCurrentUser(req.user.id);
      return res.json({
        success: true,
        user
      });
    } catch (err: any) {
      return res.status(401).json({
        success: false,
        message: err.message || 'Session expired or user not found.'
      });
    }
  },

  async logout(req: Request, res: Response, next: NextFunction) {
    try {
      if (req.user) {
        await activityLogService.log({
          userId: req.user.id,
          userName: req.user.name || req.user.email,
          action: 'LOGOUT',
          entityType: 'AUTH',
          entityId: req.user.id,
          details: 'User logged out of the application.',
          ipAddress: req.ip
        });
      }
      return res.json({
        success: true,
        message: 'Logged out successfully.'
      });
    } catch (err: any) {
      return res.status(500).json({
        success: false,
        message: 'Logout failed.'
      });
    }
  },

  async forgotPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({
          success: false,
          message: 'Email address is required.'
        });
      }
      const result = await authService.forgotPassword(email);
      return res.json({
        success: true,
        message: result.message
      });
    } catch (err: any) {
      return res.status(400).json({
        success: false,
        message: err.message || 'Request failed.'
      });
    }
  }
};
