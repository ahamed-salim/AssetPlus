import { Request, Response, NextFunction } from 'express';
import { vendorService } from '../services/vendorService';

export const vendorController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const vendors = await vendorService.getAll();
      res.json(vendors);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const v = await vendorService.getById(req.params.id);
      if (!v) return res.status(404).json({ error: 'Vendor not found.' });
      res.json(v);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await vendorService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await vendorService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Vendor not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await vendorService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Vendor not found.' });
      res.json({ message: 'Vendor deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
