import { Request, Response, NextFunction } from 'express';
import { assignmentService } from '../services/assignmentService';
import { activityLogService } from '../services/activityLogService';

export const assignmentController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const data = await assignmentService.getAll();
      res.json(data);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const item = await assignmentService.getById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Transfer or assignment record not found.' });
      res.json(item);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const created = await assignmentService.create(req.body);

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'ASSET_TRANSFERRED',
        entityType: 'TRANSFER',
        entityId: created.id,
        details: `Transferred asset ${created.assetTag || created.assetName || ''} (${created.type}).`,
        ipAddress: req.ip
      });

      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await assignmentService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Transfer record not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await assignmentService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Record not found.' });
      res.json({ message: 'Record deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
