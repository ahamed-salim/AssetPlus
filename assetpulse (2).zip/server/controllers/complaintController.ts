import { Request, Response, NextFunction } from 'express';
import { complaintService } from '../services/complaintService';

export const complaintController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const tickets = await complaintService.getAll();
      res.json(tickets);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const ticket = await complaintService.getById(req.params.id);
      if (!ticket) return res.status(404).json({ error: 'Complaint ticket not found.' });
      res.json(ticket);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await complaintService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await complaintService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Complaint ticket not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await complaintService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Ticket not found.' });
      res.json({ message: 'Ticket deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
