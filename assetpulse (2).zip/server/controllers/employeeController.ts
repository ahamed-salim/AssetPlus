import { Request, Response, NextFunction } from 'express';
import { employeeService } from '../services/employeeService';

export const employeeController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const emps = await employeeService.getAll();
      res.json(emps);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const emp = await employeeService.getById(req.params.id);
      if (!emp) return res.status(404).json({ error: 'Employee not found.' });
      res.json(emp);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await employeeService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await employeeService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Employee not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await employeeService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Employee not found.' });
      res.json({ message: 'Employee deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
