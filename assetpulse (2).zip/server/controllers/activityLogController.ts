import { Request, Response, NextFunction } from 'express';
import { activityLogService } from '../services/activityLogService';

export const activityLogController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const logs = await activityLogService.getAll();
      res.json(logs);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const user = req.user;
      const { action, entityType, entityId, details } = req.body;
      const log = await activityLogService.log({
        userId: user?.id,
        userName: user?.name,
        action,
        entityType,
        entityId,
        details,
        ipAddress: req.ip
      });
      res.status(201).json(log);
    } catch (err) {
      next(err);
    }
  }
};
