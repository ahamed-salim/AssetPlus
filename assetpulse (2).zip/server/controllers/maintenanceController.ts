import { Request, Response, NextFunction } from 'express';
import { maintenanceService } from '../services/maintenanceService';

export const maintenanceController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const pms = await maintenanceService.getAll();
      res.json(pms);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const pm = await maintenanceService.getById(req.params.id);
      if (!pm) return res.status(404).json({ error: 'Maintenance record not found.' });
      res.json(pm);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await maintenanceService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await maintenanceService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Maintenance schedule not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await maintenanceService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Maintenance schedule not found.' });
      res.json({ message: 'Maintenance schedule deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
