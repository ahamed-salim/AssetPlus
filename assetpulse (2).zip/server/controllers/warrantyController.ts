import { Request, Response, NextFunction } from 'express';
import { warrantyService } from '../services/warrantyService';

export const warrantyController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const records = await warrantyService.getAll();
      res.json(records);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const record = await warrantyService.getById(req.params.id);
      if (!record) return res.status(404).json({ error: 'Warranty record not found.' });
      res.json(record);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await warrantyService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await warrantyService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Warranty record not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await warrantyService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Warranty record not found.' });
      res.json({ message: 'Warranty record deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
