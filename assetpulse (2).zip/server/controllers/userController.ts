import { Request, Response, NextFunction } from 'express';
import { userService } from '../services/userService';
import { activityLogService } from '../services/activityLogService';

export const userController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const users = await userService.getAll();
      res.json(users);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const user = await userService.getById(req.params.id);
      if (!user) return res.status(404).json({ error: 'User not found.' });
      res.json(user);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const newUser = await userService.create(req.body);

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'USER_CREATED',
        entityType: 'USER',
        entityId: newUser.id,
        details: `Created new user ${newUser.name} (${newUser.email}) with role ${newUser.role}.`,
        ipAddress: req.ip
      });

      res.status(201).json(newUser);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const targetUserId = req.params.id;
      const requestingUser = req.user;

      if (!requestingUser) {
        return res.status(401).json({ error: 'Authentication required.' });
      }

      const existingTargetUser = await userService.getById(targetUserId);
      if (!existingTargetUser) {
        return res.status(404).json({ error: 'User not found.' });
      }

      const isSelfUpdate = requestingUser.id === targetUserId;
      const isSuperAdmin = requestingUser.role === 'super_admin';

      if (!isSelfUpdate && !isSuperAdmin) {
        return res.status(403).json({ error: 'Forbidden: You do not have permission to modify other users.' });
      }

      const updatePayload = { ...req.body };

      // Security requirement: Normal users MUST NOT edit their own role or account status
      if (!isSuperAdmin) {
        delete updatePayload.role;
        delete updatePayload.status;
      }

      // Check for last Super Admin protections
      if (existingTargetUser.role === 'super_admin') {
        const superAdminCount = await userService.getActiveSuperAdminCount();

        if (updatePayload.role && updatePayload.role !== 'super_admin' && superAdminCount <= 1) {
          return res.status(400).json({
            error: 'Cannot demote the last Super Admin account. At least one Super Admin must remain active.'
          });
        }

        if (updatePayload.status && updatePayload.status === 'Inactive' && superAdminCount <= 1) {
          return res.status(400).json({
            error: 'Cannot deactivate the last Super Admin account. At least one Super Admin must remain active.'
          });
        }
      }

      const updated = await userService.update(targetUserId, updatePayload);
      if (!updated) return res.status(404).json({ error: 'User not found.' });

      // Audit Logging
      if (updatePayload.role && updatePayload.role !== existingTargetUser.role) {
        await activityLogService.log({
          userId: requestingUser.id,
          userName: requestingUser.name || requestingUser.email,
          action: 'ROLE_CHANGED',
          entityType: 'USER',
          entityId: targetUserId,
          details: `Changed role for ${existingTargetUser.name} (${existingTargetUser.email}) from ${existingTargetUser.role} to ${updatePayload.role}.`,
          ipAddress: req.ip
        });
      } else if (updatePayload.status && updatePayload.status !== existingTargetUser.status) {
        await activityLogService.log({
          userId: requestingUser.id,
          userName: requestingUser.name || requestingUser.email,
          action: 'USER_STATUS_CHANGED',
          entityType: 'USER',
          entityId: targetUserId,
          details: `Changed status for ${existingTargetUser.name} (${existingTargetUser.email}) to ${updatePayload.status}.`,
          ipAddress: req.ip
        });
      } else {
        await activityLogService.log({
          userId: requestingUser.id,
          userName: requestingUser.name || requestingUser.email,
          action: 'USER_UPDATED',
          entityType: 'USER',
          entityId: targetUserId,
          details: `Updated profile details for ${existingTargetUser.name}.`,
          ipAddress: req.ip
        });
      }

      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const targetUserId = req.params.id;

      const existingTargetUser = await userService.getById(targetUserId);
      if (!existingTargetUser) {
        return res.status(404).json({ error: 'User not found.' });
      }

      if (existingTargetUser.role === 'super_admin') {
        const superAdminCount = await userService.getActiveSuperAdminCount();
        if (superAdminCount <= 1) {
          return res.status(400).json({
            error: 'Cannot delete the last Super Admin account. At least one Super Admin must remain in the system.'
          });
        }
      }

      const success = await userService.delete(targetUserId);
      if (!success) return res.status(404).json({ error: 'User not found.' });

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'USER_DELETED',
        entityType: 'USER',
        entityId: targetUserId,
        details: `Deleted user account ${existingTargetUser.name} (${existingTargetUser.email}).`,
        ipAddress: req.ip
      });

      res.json({ message: 'User deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
