import { Request, Response, NextFunction } from 'express';
import { departmentService } from '../services/departmentService';

export const departmentController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const depts = await departmentService.getAll();
      res.json(depts);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const dept = await departmentService.getById(req.params.id);
      if (!dept) return res.status(404).json({ error: 'Department not found.' });
      res.json(dept);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await departmentService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await departmentService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Department not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await departmentService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Department not found.' });
      res.json({ message: 'Department deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
