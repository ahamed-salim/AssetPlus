import { Request, Response, NextFunction } from 'express';
import { assetService } from '../services/assetService';
import { activityLogService } from '../services/activityLogService';

export const assetController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const assets = await assetService.getAll();
      res.json(assets);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const asset = await assetService.getById(req.params.id);
      if (!asset) return res.status(404).json({ error: 'Asset not found.' });
      res.json(asset);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const created = await assetService.create(req.body);

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'ASSET_CREATED',
        entityType: 'ASSET',
        entityId: created.id,
        details: `Registered asset ${created.tag} (${created.name}).`,
        ipAddress: req.ip
      });

      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const updated = await assetService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Asset not found.' });

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'ASSET_UPDATED',
        entityType: 'ASSET',
        entityId: updated.id,
        details: `Updated details for asset ${updated.tag} (${updated.name}).`,
        ipAddress: req.ip
      });

      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const requestingUser = req.user;
      const targetAsset = await assetService.getById(req.params.id);
      const success = await assetService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Asset not found.' });

      await activityLogService.log({
        userId: requestingUser?.id,
        userName: requestingUser?.name || requestingUser?.email,
        action: 'ASSET_DELETED',
        entityType: 'ASSET',
        entityId: req.params.id,
        details: `Deleted asset ${targetAsset?.tag || req.params.id} (${targetAsset?.name || 'Asset'}).`,
        ipAddress: req.ip
      });

      res.json({ message: 'Asset deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
