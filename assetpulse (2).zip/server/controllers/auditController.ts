import { Request, Response, NextFunction } from 'express';
import { auditService } from '../services/auditService';

export const auditController = {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const audits = await auditService.getAll();
      res.json(audits);
    } catch (err) {
      next(err);
    }
  },

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const audit = await auditService.getById(req.params.id);
      if (!audit) return res.status(404).json({ error: 'Audit campaign not found.' });
      res.json(audit);
    } catch (err) {
      next(err);
    }
  },

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const created = await auditService.create(req.body);
      res.status(201).json(created);
    } catch (err) {
      next(err);
    }
  },

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const updated = await auditService.update(req.params.id, req.body);
      if (!updated) return res.status(404).json({ error: 'Audit campaign not found.' });
      res.json(updated);
    } catch (err) {
      next(err);
    }
  },

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const success = await auditService.delete(req.params.id);
      if (!success) return res.status(404).json({ error: 'Audit campaign not found.' });
      res.json({ message: 'Audit campaign deleted successfully.' });
    } catch (err) {
      next(err);
    }
  }
};
