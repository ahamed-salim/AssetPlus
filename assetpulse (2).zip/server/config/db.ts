import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import {
  mockUsers,
  mockDepartments,
  mockEmployees,
  mockVendors,
  mockAssets,
  mockTransfers,
  mockComplaints,
  mockRepairs,
  mockPMs,
  mockWarranties,
  mockAudits,
  mockDisposals,
  mockActivityLogs
} from '../../src/data/mockData';

// Database connection pool
let pool: mysql.Pool | null = null;
let isMySQLEnabled = false;

// Pre-compute standard password hash for demo accounts ('password123')
const defaultPasswordHash = bcrypt.hashSync('password123', 10);

// In-Memory fallback database store initialized with mock data
export const inMemoryDb = {
  users: mockUsers.map(u => ({
    ...u,
    password_hash: defaultPasswordHash
  })),
  departments: [...mockDepartments],
  employees: [...mockEmployees],
  vendors: [...mockVendors],
  assets: [...mockAssets],
  transfers: [...mockTransfers],
  complaints: [...mockComplaints],
  repairs: [...mockRepairs],
  maintenance: [...mockPMs],
  warranties: [...mockWarranties],
  audits: [...mockAudits],
  disposals: [...mockDisposals],
  activityLogs: [...mockActivityLogs]
};

export async function initDatabase() {
  const host = process.env.MYSQL_HOST || process.env.DB_HOST;
  const user = process.env.MYSQL_USER || process.env.DB_USER;
  const password = process.env.MYSQL_PASSWORD || process.env.DB_PASSWORD;
  const database = process.env.MYSQL_DATABASE || process.env.DB_NAME || 'assetpulse';

  if (host && user) {
    try {
      pool = mysql.createPool({
        host,
        user,
        password,
        database,
        port: Number(process.env.MYSQL_PORT || 3306),
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
      });

      // Test connection
      const connection = await pool.getConnection();
      console.log('✅ Successfully connected to MySQL Database on', host);
      connection.release();
      isMySQLEnabled = true;
      
      await setupTables();
    } catch (error) {
      console.warn('⚠️ Could not connect to external MySQL instance. Falling back to active in-memory repository engine.', error);
      isMySQLEnabled = false;
    }
  } else {
    console.log('ℹ️ No MYSQL_HOST configured. Using active memory store with pre-seeded data.');
    isMySQLEnabled = false;
  }
}

async function setupTables() {
  if (!pool) return;

  const createTableQueries = [
    `CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(100) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role VARCHAR(50) NOT NULL,
      avatar TEXT,
      departmentId VARCHAR(50),
      departmentName VARCHAR(100),
      title VARCHAR(100),
      phone VARCHAR(50),
      status VARCHAR(50) DEFAULT 'Active',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS departments (
      id VARCHAR(50) PRIMARY KEY,
      code VARCHAR(20) NOT NULL,
      name VARCHAR(100) NOT NULL,
      headName VARCHAR(100),
      location VARCHAR(100),
      totalAssets INT DEFAULT 0,
      budgetAllocated DECIMAL(12,2) DEFAULT 0
    )`,
    `CREATE TABLE IF NOT EXISTS employees (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(100) NOT NULL,
      role VARCHAR(50),
      departmentId VARCHAR(50),
      departmentName VARCHAR(100),
      location VARCHAR(100),
      phone VARCHAR(50),
      avatar TEXT,
      assignedAssetCount INT DEFAULT 0,
      status VARCHAR(50) DEFAULT 'Active'
    )`,
    `CREATE TABLE IF NOT EXISTS vendors (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      contactPerson VARCHAR(100),
      email VARCHAR(100),
      phone VARCHAR(50),
      category VARCHAR(50),
      rating DECIMAL(3,2) DEFAULT 5.0,
      activeContracts INT DEFAULT 0,
      linkedAssetsCount INT DEFAULT 0,
      slaResponseHours INT DEFAULT 24
    )`,
    `CREATE TABLE IF NOT EXISTS assets (
      id VARCHAR(50) PRIMARY KEY,
      tag VARCHAR(50) UNIQUE NOT NULL,
      name VARCHAR(100) NOT NULL,
      category VARCHAR(50) NOT NULL,
      brand VARCHAR(50),
      model VARCHAR(50),
      serialNumber VARCHAR(100),
      departmentId VARCHAR(50),
      departmentName VARCHAR(100),
      assignedEmployeeId VARCHAR(50),
      assignedEmployeeName VARCHAR(100),
      location VARCHAR(100),
      status VARCHAR(50) NOT NULL,
      assetCondition VARCHAR(50),
      purchaseDate VARCHAR(20),
      purchaseCost DECIMAL(12,2) DEFAULT 0,
      currentValue DECIMAL(12,2) DEFAULT 0,
      salvageValue DECIMAL(12,2) DEFAULT 0,
      expectedLifespanYears INT DEFAULT 5,
      warrantyExpiry VARCHAR(20),
      warrantyVendor VARCHAR(100),
      warrantyStatus VARCHAR(50),
      qrCode TEXT,
      notes TEXT
    )`,
    `CREATE TABLE IF NOT EXISTS activity_logs (
      id VARCHAR(50) PRIMARY KEY,
      user_id VARCHAR(50),
      user_name VARCHAR(100),
      action VARCHAR(100) NOT NULL,
      entity_type VARCHAR(50) NOT NULL,
      entity_id VARCHAR(50) NOT NULL,
      details TEXT,
      ip_address VARCHAR(45),
      created_at VARCHAR(50) NOT NULL
    )`
  ];

  for (const q of createTableQueries) {
    try {
      await pool.query(q);
    } catch (err) {
      console.error('Error setting up table schema:', err);
    }
  }
}

export function isMySQLConnected(): boolean {
  return isMySQLEnabled;
}

export async function query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
  if (isMySQLEnabled && pool) {
    const [rows] = await pool.query(sql, params);
    return rows as T[];
  }
  return [];
}
