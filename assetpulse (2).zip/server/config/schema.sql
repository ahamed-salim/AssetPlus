-- ============================================================================
-- AssetPulse Enterprise IT Asset & Lifecycle Management Database Schema
-- RDBMS: MySQL 8.0+
-- ============================================================================

CREATE DATABASE IF NOT EXISTS assetpulse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE assetpulse;

SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables for clean setup
DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS disposals;
DROP TABLE IF EXISTS audit_items;
DROP TABLE IF EXISTS audits;
DROP TABLE IF EXISTS warranties;
DROP TABLE IF EXISTS maintenance;
DROP TABLE IF EXISTS repairs;
DROP TABLE IF EXISTS complaints;
DROP TABLE IF EXISTS transfers;
DROP TABLE IF EXISTS assignments;
DROP TABLE IF EXISTS assets;
DROP TABLE IF EXISTS asset_categories;
DROP TABLE IF EXISTS vendors;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS roles;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------------
-- 1. Roles Table
-- ----------------------------------------------------------------------------
CREATE TABLE roles (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 2. Departments Table
-- ----------------------------------------------------------------------------
CREATE TABLE departments (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    head_name VARCHAR(100),
    location VARCHAR(100),
    budget_allocated DECIMAL(12,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_dept_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 3. Users Table (System Auth Accounts)
-- ----------------------------------------------------------------------------
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) DEFAULT '$2a$10$abcdefghijklmnopqrstuvwxyz123456', -- Default hash
    role_id VARCHAR(50) NOT NULL,
    department_id VARCHAR(50),
    title VARCHAR(100),
    phone VARCHAR(50),
    avatar_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_user_email (email),
    INDEX idx_user_role (role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 4. Employees Table (Personnel)
-- ----------------------------------------------------------------------------
CREATE TABLE employees (
    id VARCHAR(50) PRIMARY KEY,
    employee_code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    department_id VARCHAR(50),
    job_title VARCHAR(100),
    location VARCHAR(100),
    phone VARCHAR(50),
    avatar_url TEXT,
    status ENUM('Active', 'On Leave', 'Terminated') DEFAULT 'Active',
    joined_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_emp_code (employee_code),
    INDEX idx_emp_dept (department_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 5. Vendors Table
-- ----------------------------------------------------------------------------
CREATE TABLE vendors (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(50),
    category VARCHAR(50),
    rating DECIMAL(3,2) DEFAULT 5.00,
    sla_response_hours INT DEFAULT 24,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_vendor_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 6. Asset Categories Table
-- ----------------------------------------------------------------------------
CREATE TABLE asset_categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    code VARCHAR(20) NOT NULL UNIQUE,
    description VARCHAR(255),
    depreciation_rate_percent DECIMAL(5,2) DEFAULT 20.00,
    default_lifespan_years INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 7. Assets Table (Core Inventory)
-- ----------------------------------------------------------------------------
CREATE TABLE assets (
    id VARCHAR(50) PRIMARY KEY,
    tag VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    category_id VARCHAR(50) NOT NULL,
    brand VARCHAR(50),
    model VARCHAR(50),
    serial_number VARCHAR(100) UNIQUE,
    department_id VARCHAR(50),
    assigned_employee_id VARCHAR(50),
    location VARCHAR(100) NOT NULL,
    status ENUM('Available', 'In Use', 'Under Repair', 'Maintenance', 'Disposed', 'Lost/Stolen') NOT NULL DEFAULT 'Available',
    asset_condition ENUM('Excellent', 'Good', 'Fair', 'Poor', 'Damaged') DEFAULT 'Good',
    purchase_date DATE,
    purchase_cost DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    current_value DECIMAL(12,2) DEFAULT 0.00,
    salvage_value DECIMAL(12,2) DEFAULT 0.00,
    expected_lifespan_years INT DEFAULT 5,
    qr_code TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES asset_categories(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (assigned_employee_id) REFERENCES employees(id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_asset_tag (tag),
    INDEX idx_asset_status (status),
    INDEX idx_asset_dept (department_id),
    INDEX idx_asset_employee (assigned_employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 8. Assignments Table (Custody Checkouts)
-- ----------------------------------------------------------------------------
CREATE TABLE assignments (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL,
    employee_id VARCHAR(50) NOT NULL,
    assigned_by_user_id VARCHAR(50),
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    return_due_date DATE,
    returned_date TIMESTAMP NULL,
    status ENUM('Active', 'Returned', 'Overdue') DEFAULT 'Active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (assigned_by_user_id) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_assign_asset (asset_id),
    INDEX idx_assign_employee (employee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 9. Transfers Table (Inter-Departmental or Location Movement)
-- ----------------------------------------------------------------------------
CREATE TABLE transfers (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL,
    transfer_type ENUM('Departmental', 'Employee Custody', 'Location Relocation', 'Storage Checkin') NOT NULL,
    from_department_id VARCHAR(50),
    to_department_id VARCHAR(50),
    from_employee_id VARCHAR(50),
    to_employee_id VARCHAR(50),
    initiated_by_user_id VARCHAR(50),
    status ENUM('Approved', 'Pending Approval', 'Completed', 'Rejected') DEFAULT 'Pending Approval',
    effective_date DATE NOT NULL,
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (from_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (to_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (from_employee_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (to_employee_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (initiated_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_trf_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 10. Complaints Table (Service Desk Issues)
-- ----------------------------------------------------------------------------
CREATE TABLE complaints (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL,
    reported_by_employee_id VARCHAR(50),
    assigned_technician_id VARCHAR(50),
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    priority ENUM('Low', 'Medium', 'High', 'Critical') DEFAULT 'Medium',
    status ENUM('Open', 'In Progress', 'Resolved', 'Closed') DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (reported_by_employee_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_technician_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_complaint_asset (asset_id),
    INDEX idx_complaint_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 11. Repairs Table (Work Orders)
-- ----------------------------------------------------------------------------
CREATE TABLE repairs (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL,
    complaint_id VARCHAR(50),
    vendor_id VARCHAR(50),
    issue_description TEXT NOT NULL,
    work_performed TEXT,
    repair_cost DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('Scheduled', 'In Progress', 'Awaiting Parts', 'Completed', 'Cancelled') DEFAULT 'In Progress',
    start_date DATE NOT NULL,
    expected_completion_date DATE,
    actual_completion_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE SET NULL,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
    INDEX idx_repair_asset (asset_id),
    INDEX idx_repair_vendor (vendor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 12. Maintenance Table (Preventive Schedules)
-- ----------------------------------------------------------------------------
CREATE TABLE maintenance (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    frequency ENUM('Monthly', 'Quarterly', 'Semi-Annual', 'Annual') NOT NULL,
    next_due_date DATE NOT NULL,
    last_completed_date DATE,
    target_asset_count INT DEFAULT 0,
    vendor_id VARCHAR(50),
    assigned_technician_id VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_technician_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 13. Warranties Table
-- ----------------------------------------------------------------------------
CREATE TABLE warranties (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL UNIQUE,
    vendor_id VARCHAR(50),
    coverage_type VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    claim_contact VARCHAR(100),
    status ENUM('Active', 'Expiring Soon', 'Expired', 'Claim Pending') DEFAULT 'Active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE SET NULL,
    INDEX idx_warranty_expiry (expiry_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 14. Audits Table (Physical Reconciliation Campaigns)
-- ----------------------------------------------------------------------------
CREATE TABLE audits (
    id VARCHAR(50) PRIMARY KEY,
    campaign_name VARCHAR(150) NOT NULL,
    target_department_id VARCHAR(50),
    lead_auditor_id VARCHAR(50),
    start_date DATE NOT NULL,
    due_date DATE NOT NULL,
    total_expected_assets INT DEFAULT 0,
    scanned_assets INT DEFAULT 0,
    discrepant_assets INT DEFAULT 0,
    status ENUM('Draft', 'In Progress', 'Completed', 'Archived') DEFAULT 'In Progress',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (target_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    FOREIGN KEY (lead_auditor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 15. Audit Items Table (Individual Scan Reconciliations)
-- ----------------------------------------------------------------------------
CREATE TABLE audit_items (
    id VARCHAR(50) PRIMARY KEY,
    audit_id VARCHAR(50) NOT NULL,
    asset_id VARCHAR(50) NOT NULL,
    expected_location VARCHAR(100),
    scanned_location VARCHAR(100),
    scanned_by_user_id VARCHAR(50),
    scanned_at TIMESTAMP NULL,
    verification_status ENUM('Verified', 'Missing', 'Misplaced', 'Damaged', 'Pending') DEFAULT 'Pending',
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (audit_id) REFERENCES audits(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (scanned_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uk_audit_asset (audit_id, asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 16. Disposals Table (E-Waste & Salvage Retirement)
-- ----------------------------------------------------------------------------
CREATE TABLE disposals (
    id VARCHAR(50) PRIMARY KEY,
    asset_id VARCHAR(50) NOT NULL UNIQUE,
    approved_by_user_id VARCHAR(50),
    reason ENUM('End of Life', 'Irreparable Damage', 'Obsolete Technology', 'Lost/Stolen', 'Donation') NOT NULL,
    method ENUM('Certified E-Waste Recycler', 'Auction / Salvage Sale', 'Vendor Trade-In', 'Scrapped / Destruction') NOT NULL,
    salvage_value_realized DECIMAL(10,2) DEFAULT 0.00,
    disposal_date DATE NOT NULL,
    certificate_number VARCHAR(100),
    status ENUM('Pending Approval', 'Approved', 'Completed', 'Cancelled') DEFAULT 'Completed',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 17. Notifications Table
-- ----------------------------------------------------------------------------
CREATE TABLE notifications (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'warning', 'error', 'success') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    link_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_notif_user (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------------------
-- 18. Activity Logs Table (Audit Trail)
-- ----------------------------------------------------------------------------
CREATE TABLE activity_logs (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50),
    user_name VARCHAR(100),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_act_entity (entity_type, entity_id),
    INDEX idx_act_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================================
-- SEED DATA INSERTION
-- ============================================================================

-- Seed Roles
INSERT INTO roles (id, name, description) VALUES
('ROLE-01', 'super_admin', 'Full system access and global configuration privileges'),
('ROLE-02', 'asset_manager', 'Manages hardware inventory, vendors, transfers, and disposals'),
('ROLE-03', 'technician', 'Handles repair tickets, preventive maintenance, and audits'),
('ROLE-04', 'employee', 'General employee viewing assigned equipment and submitting requests');

-- Seed Departments
INSERT INTO departments (id, code, name, head_name, location, budget_allocated) VALUES
('DEP-001', 'IT-OPS', 'IT Operations', 'Alexander Wright', 'HQ - Floor 4', 450000.00),
('DEP-002', 'ENG-DEV', 'Software Engineering', 'Elena Rostova', 'HQ - Floor 3', 680000.00),
('DEP-003', 'FIN-ACC', 'Finance & Accounting', 'Marcus Vance', 'HQ - Floor 2', 210000.00),
('DEP-004', 'HR-TAL', 'Human Resources', 'Sophia Chen', 'HQ - Floor 2', 150000.00),
('DEP-005', 'MKT-DES', 'Design & Marketing', 'Liam Hemsworth', 'Creative Annex', 290000.00);

-- Seed Categories
INSERT INTO asset_categories (id, name, code, description, depreciation_rate_percent, default_lifespan_years) VALUES
('CAT-01', 'Laptops & Workstations', 'LAPTOP', 'Mobile computing workstations and Ultrabooks', 25.00, 4),
('CAT-02', 'Monitors & Displays', 'DISPLAY', 'UltraWide 4K and color-calibrated monitors', 20.00, 5),
('CAT-03', 'Servers & Networking', 'SERVER', 'Rackmount servers, switches, and firewalls', 15.00, 6),
('CAT-04', 'Peripherals & Accessories', 'PERIPH', 'Keyboards, docks, webcams, and audio devices', 33.33, 3),
('CAT-05', 'Mobile Devices & Tablets', 'MOBILE', 'Smartphones and testing tablets', 30.00, 3);

-- Seed Users
INSERT INTO users (id, name, email, role_id, department_id, title, phone, avatar_url) VALUES
('USR-001', 'Alexander Wright', 'alexander.wright@assetpulse.com', 'ROLE-01', 'DEP-001', 'Global IT Director', '+1 (555) 019-2834', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250'),
('USR-002', 'Elena Rostova', 'elena.rostova@assetpulse.com', 'ROLE-02', 'DEP-002', 'VP of Engineering', '+1 (555) 019-2835', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250'),
('USR-003', 'David Miller', 'david.miller@assetpulse.com', 'ROLE-03', 'DEP-001', 'Lead Hardware Technician', '+1 (555) 019-2836', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250');

-- Seed Employees
INSERT INTO employees (id, employee_code, name, email, department_id, job_title, location, phone, avatar_url, status) VALUES
('EMP-001', 'EMP-1001', 'Alexander Wright', 'alexander.wright@assetpulse.com', 'DEP-001', 'Global IT Director', 'HQ - Floor 4', '+1 (555) 019-2834', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250', 'Active'),
('EMP-002', 'EMP-1002', 'Elena Rostova', 'elena.rostova@assetpulse.com', 'DEP-002', 'VP of Engineering', 'HQ - Floor 3', '+1 (555) 019-2835', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250', 'Active'),
('EMP-003', 'EMP-1003', 'Marcus Vance', 'marcus.vance@assetpulse.com', 'DEP-003', 'Finance Director', 'HQ - Floor 2', '+1 (555) 019-2836', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250', 'Active'),
('EMP-004', 'EMP-1004', 'Sophia Chen', 'sophia.chen@assetpulse.com', 'DEP-004', 'HR Lead', 'HQ - Floor 2', '+1 (555) 019-2837', 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=250', 'Active');

-- Seed Vendors
INSERT INTO vendors (id, name, contact_person, email, phone, category, rating, sla_response_hours) VALUES
('VND-001', 'Apple Business Direct', 'Sarah Jenkins', 'enterprise@apple.com', '+1 (800) 854-3680', 'Hardware OEM', 4.9, 12),
('VND-002', 'Dell Enterprise Technologies', 'Michael Chang', 'support@dell.com', '+1 (800) 456-3355', 'Hardware OEM', 4.7, 24),
('VND-003', 'CDW Government & Commercial', 'Robert Downey', 'sales@cdw.com', '+1 (800) 800-4239', 'IT Reseller', 4.8, 8);

-- Seed Assets
INSERT INTO assets (id, tag, name, category_id, brand, model, serial_number, department_id, assigned_employee_id, location, status, asset_condition, purchase_date, purchase_cost, current_value, salvage_value, expected_lifespan_years, qr_code) VALUES
('AST-001', 'AST-2026-001', 'MacBook Pro 16" M3 Max', 'CAT-01', 'Apple', 'MacBook Pro M3 Max 36GB', 'C02G102XQ01', 'DEP-002', 'EMP-002', 'HQ - Floor 3', 'In Use', 'Excellent', '2025-11-15', 3899.00, 3119.20, 500.00, 4, 'AP-AST-2026-001-001'),
('AST-002', 'AST-2026-002', 'Dell XPS 17 Workstation', 'CAT-01', 'Dell', 'XPS 9730 i9 64GB', 'DLXPS9730-8821', 'DEP-001', 'EMP-001', 'HQ - Floor 4', 'In Use', 'Good', '2025-08-20', 2999.00, 2249.25, 400.00, 4, 'AP-AST-2026-002-002'),
('AST-003', 'AST-2026-003', 'Dell UltraSharp 34" Curved Monitor', 'CAT-02', 'Dell', 'U3423WE Curved USB-C Hub', 'CN-0U3423-74400', 'DEP-002', 'EMP-002', 'HQ - Floor 3', 'In Use', 'Excellent', '2025-09-10', 899.00, 719.20, 100.00, 5, 'AP-AST-2026-003-003'),
('AST-004', 'AST-2026-004', 'Lenovo ThinkPad X1 Carbon', 'CAT-01', 'Lenovo', 'X1 Gen 11 i7', 'LNV-X1-99812', 'DEP-003', 'EMP-003', 'HQ - Floor 2', 'Under Repair', 'Fair', '2024-03-12', 2149.00, 1074.50, 200.00, 4, 'AP-AST-2026-004-004');

-- Seed Warranties
INSERT INTO warranties (id, asset_id, vendor_id, coverage_type, start_date, expiry_date, claim_contact, status) VALUES
('WRN-001', 'AST-001', 'VND-001', 'AppleCare+ for Enterprise (3-Year Tier)', '2025-11-15', '2028-11-15', 'applecare@assetpulse.com', 'Active'),
('WRN-002', 'AST-002', 'VND-002', 'Dell ProSupport Plus Onsite', '2025-08-20', '2026-08-20', 'prosupport@dell.com', 'Expiring Soon'),
('WRN-003', 'AST-004', 'VND-003', 'Lenovo Premier Support', '2024-03-12', '2027-03-12', 'premier@lenovo.com', 'Active');

-- Seed Repairs
INSERT INTO repairs (id, asset_id, vendor_id, issue_description, work_performed, repair_cost, status, start_date, expected_completion_date) VALUES
('REP-001', 'AST-004', 'VND-002', 'Motherboard power rail fault causing unexpected system shutdowns.', 'Diagnosed power controller defect. Parts dispatched under warranty.', 420.00, 'In Progress', '2026-08-01', '2026-08-12');

-- Seed Maintenance
INSERT INTO maintenance (id, title, category, frequency, next_due_date, target_asset_count, vendor_id, is_active) VALUES
('PM-001', 'Quarterly Server & UPS Battery Inspection', 'Servers & Infrastructure', 'Quarterly', '2026-09-15', 18, 'VND-002', TRUE),
('PM-002', 'Workstation Thermal Paste & Dust Cleanout', 'Laptops & Desktops', 'Semi-Annual', '2026-10-01', 45, 'VND-003', TRUE);

-- Seed Audits
INSERT INTO audits (id, campaign_name, target_department_id, lead_auditor_id, start_date, due_date, total_expected_assets, scanned_assets, discrepant_assets, status) VALUES
('AUD-001', 'Q3 Engineering Workstation Compliance Sweep', 'DEP-002', 'USR-001', '2026-08-01', '2026-08-31', 42, 38, 2, 'In Progress');

-- Seed Audit Items
INSERT INTO audit_items (id, audit_id, asset_id, expected_location, scanned_location, scanned_by_user_id, scanned_at, verification_status) VALUES
('ADI-001', 'AUD-001', 'AST-001', 'HQ - Floor 3', 'HQ - Floor 3', 'USR-001', '2026-08-02 10:15:00', 'Verified'),
('ADI-002', 'AUD-001', 'AST-003', 'HQ - Floor 3', 'HQ - Floor 3', 'USR-001', '2026-08-02 10:18:00', 'Verified');

-- Seed Disposals
INSERT INTO disposals (id, asset_id, approved_by_user_id, reason, method, salvage_value_realized, disposal_date, certificate_number, status) VALUES
('DSP-001', 'AST-004', 'USR-001', 'End of Life', 'Certified E-Waste Recycler', 150.00, '2026-07-15', 'CERT-EW-2026-9901', 'Completed');

-- Seed Notifications
INSERT INTO notifications (id, user_id, title, message, type, is_read) VALUES
('NTF-001', 'USR-001', 'Warranty Expiring Soon', 'Dell XPS Workstation (AST-2026-002) warranty expires in 11 days.', 'warning', FALSE),
('NTF-002', 'USR-001', 'New Repair Workorder Created', 'Repair ticket #REP-001 created for ThinkPad X1 Carbon.', 'info', TRUE);

-- Seed Activity Logs
INSERT INTO activity_logs (id, user_id, user_name, action, entity_type, entity_id, details) VALUES
('LOG-001', 'USR-001', 'Alexander Wright', 'CREATED', 'ASSET', 'AST-2026-001', 'Registered MacBook Pro 16 M3 Max into inventory.'),
('LOG-002', 'USR-001', 'Alexander Wright', 'ASSIGNED', 'ASSET', 'AST-2026-001', 'Assigned custody to Elena Rostova (VP of Engineering).');

-- Done
