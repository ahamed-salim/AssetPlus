import { Router } from 'express';
import { disposalController } from '../controllers/disposalController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', disposalController.getAll);
router.get('/:id', disposalController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['assetId', 'reason']), disposalController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), disposalController.update);
router.delete('/:id', authorizeRoles('super_admin'), disposalController.delete);

export default router;
