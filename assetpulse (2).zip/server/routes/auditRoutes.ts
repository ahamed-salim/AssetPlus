import { Router } from 'express';
import { auditController } from '../controllers/auditController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', auditController.getAll);
router.get('/:id', auditController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['campaignName', 'targetDepartment']), auditController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), auditController.update);
router.delete('/:id', authorizeRoles('super_admin'), auditController.delete);

export default router;
