import { Router } from 'express';
import { departmentController } from '../controllers/departmentController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', departmentController.getAll);
router.get('/:id', departmentController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['name', 'code']), departmentController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), departmentController.update);
router.delete('/:id', authorizeRoles('super_admin'), departmentController.delete);

export default router;
