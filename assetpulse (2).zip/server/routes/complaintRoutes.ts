import { Router } from 'express';
import { complaintController } from '../controllers/complaintController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', complaintController.getAll);
router.get('/:id', complaintController.getById);
router.post('/', validateRequiredFields(['assetId', 'title', 'description']), complaintController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager', 'technician'), complaintController.update);
router.delete('/:id', authorizeRoles('super_admin'), complaintController.delete);

export default router;
