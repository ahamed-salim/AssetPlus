import { Router } from 'express';
import { maintenanceController } from '../controllers/maintenanceController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', maintenanceController.getAll);
router.get('/:id', maintenanceController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager', 'technician'), validateRequiredFields(['title', 'category', 'frequency']), maintenanceController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager', 'technician'), maintenanceController.update);
router.delete('/:id', authorizeRoles('super_admin'), maintenanceController.delete);

export default router;
