import { Router } from 'express';
import { repairController } from '../controllers/repairController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', repairController.getAll);
router.get('/:id', repairController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager', 'technician'), validateRequiredFields(['assetId', 'issueDescription']), repairController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager', 'technician'), repairController.update);
router.delete('/:id', authorizeRoles('super_admin'), repairController.delete);

export default router;
