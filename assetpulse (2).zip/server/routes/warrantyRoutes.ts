import { Router } from 'express';
import { warrantyController } from '../controllers/warrantyController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', warrantyController.getAll);
router.get('/:id', warrantyController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['assetId', 'vendorName', 'expiryDate']), warrantyController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), warrantyController.update);
router.delete('/:id', authorizeRoles('super_admin'), warrantyController.delete);

export default router;
