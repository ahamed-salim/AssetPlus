import { Router } from 'express';
import { authController } from '../controllers/authController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.post('/login', authController.login);
router.post('/register', authController.register);
router.get('/me', authenticateToken, authController.me);
router.post('/logout', authController.logout);
router.post('/forgot-password', authController.forgotPassword);

export default router;
