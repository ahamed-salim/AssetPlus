import { Router } from 'express';
import { employeeController } from '../controllers/employeeController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', employeeController.getAll);
router.get('/:id', employeeController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['name', 'email']), employeeController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), employeeController.update);
router.delete('/:id', authorizeRoles('super_admin'), employeeController.delete);

export default router;
