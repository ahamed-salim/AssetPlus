import { Router } from 'express';
import { userController } from '../controllers/userController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', userController.getAll);
router.get('/:id', userController.getById);
router.post('/', authorizeRoles('super_admin'), validateRequiredFields(['name', 'email', 'role']), userController.create);
router.put('/:id', userController.update);
router.delete('/:id', authorizeRoles('super_admin'), userController.delete);

export default router;
