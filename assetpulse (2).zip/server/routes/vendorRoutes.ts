import { Router } from 'express';
import { vendorController } from '../controllers/vendorController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', vendorController.getAll);
router.get('/:id', vendorController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['name']), vendorController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), vendorController.update);
router.delete('/:id', authorizeRoles('super_admin'), vendorController.delete);

export default router;
