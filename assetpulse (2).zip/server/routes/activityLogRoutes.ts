import { Router } from 'express';
import { activityLogController } from '../controllers/activityLogController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

router.get('/', activityLogController.getAll);
router.post('/', activityLogController.create);

export default router;
