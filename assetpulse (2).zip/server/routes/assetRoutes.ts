import { Router } from 'express';
import { assetController } from '../controllers/assetController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', assetController.getAll);
router.get('/:id', assetController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager'), validateRequiredFields(['tag', 'name', 'category', 'status']), assetController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager', 'technician'), assetController.update);
router.delete('/:id', authorizeRoles('super_admin'), assetController.delete);

export default router;
