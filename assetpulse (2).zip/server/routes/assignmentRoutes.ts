import { Router } from 'express';
import { assignmentController } from '../controllers/assignmentController';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { validateRequiredFields } from '../middleware/validate';

const router = Router();

router.use(authenticateToken);

router.get('/', assignmentController.getAll);
router.get('/:id', assignmentController.getById);
router.post('/', authorizeRoles('super_admin', 'asset_manager', 'employee'), validateRequiredFields(['assetId', 'type']), assignmentController.create);
router.put('/:id', authorizeRoles('super_admin', 'asset_manager'), assignmentController.update);
router.delete('/:id', authorizeRoles('super_admin'), assignmentController.delete);

export default router;
