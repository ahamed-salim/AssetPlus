import { Router } from 'express';
import authRoutes from './authRoutes';
import userRoutes from './userRoutes';
import departmentRoutes from './departmentRoutes';
import employeeRoutes from './employeeRoutes';
import vendorRoutes from './vendorRoutes';
import assetRoutes from './assetRoutes';
import assignmentRoutes from './assignmentRoutes';
import complaintRoutes from './complaintRoutes';
import repairRoutes from './repairRoutes';
import maintenanceRoutes from './maintenanceRoutes';
import warrantyRoutes from './warrantyRoutes';
import auditRoutes from './auditRoutes';
import disposalRoutes from './disposalRoutes';
import activityLogRoutes from './activityLogRoutes';

const router = Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/departments', departmentRoutes);
router.use('/employees', employeeRoutes);
router.use('/vendors', vendorRoutes);
router.use('/assets', assetRoutes);
router.use('/transfers', assignmentRoutes);
router.use('/complaints', complaintRoutes);
router.use('/repairs', repairRoutes);
router.use('/maintenance', maintenanceRoutes);
router.use('/warranties', warrantyRoutes);
router.use('/audits', auditRoutes);
router.use('/disposals', disposalRoutes);
router.use('/activity-logs', activityLogRoutes);

export default router;
